# PL-DOS FS / SD FDD interchange — decision memo

**Date:** 2026-07-13
**Status:** design discussion — **not adopted normative**
**Active FS remains:** PLFS ([reference/software/plover-fat.md](../../reference/software/plover-fat.md))

Compressed notes from a 2026-07-13 design thread. Not a chat transcript.

## 1. Intent

- PL-DOS uses microSD (or a region of it) as a virtual FDD.
- Coprocessor is a **sector / LBA mediator only** — no load/unload and no filesystem parsing on the copro.

## 2. Layering

```text
PL-DOS filesystem
  -> Mailbox sector R/W
  -> RP235x copro (block bridge)
  -> microSD
```

Matches existing vFDD + Mailbox contracts.

## 3. PLFS (Active S7b)

- Minimal flat catalog for PL-DOS v0.1 education.
- Not recognizable by Windows / Linux / macOS Explorer as a volume.

## 4. PC SD interchange goal

- Pull SD, copy files on a host PC, reinsert, run on Plover.
- Same volume readable by Win/Linux/mac requires **FAT12** (8.3) implemented **in PL-DOS**, not in the copro.
- Historical note: Apple II used DOS 3.3 / ProDOS (not Microsoft FAT).

## 5. Geometry (discussion only)

- Prefer **512-byte clusters** (1 sector/cluster): aligns with vFDD 512 B sectors, `FS_DIR_CACHE` one-sector model, and Mailbox per-sector cost.
- FAT12 practical volume ceiling ~16 MB (larger clusters can reach ~32 MB); fine for FDD-sized slices.

## 6. Mailbox window

- Hard cap: `$FF00–$FFFB` (252 B total; 248 B payload). `$FFFC–$FFFF` are vectors — never mailbox.
- Enlarging the MMIO window for faster cluster transfer collides with the vector page → **not recommended** for v1.0.
- Prefer burst/chunk protocol improvements while keeping the 248 B window.

## 7. Performance

- ~2 MHz TTL CPU + polling I/O is enough for FDD-class `DIR` and small `.PLR` loads.
- Not a target for continuous large-file streaming from disk every frame.
- PLFS exists to cut implementation size, not because FAT12 is impossible on this machine.

## 8. Active policy

- Normative on-disk FS for S7b remains **PLFS**.
- This memo does **not** change reference docs, whitepaper, or roadmap.
- Cite Active specs only; restore this tarball only for historical comparison.
