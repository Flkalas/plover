# G Plan — dual CPLD JTAG daisy chain

**Reference:** [cpld_fsm/tools/wiring-flash.md](../../tools/wiring-flash.md) · ATF1504 PLCC-44 ISP pins

---

## Pin assignment (per device)

| JTAG | PLCC pin |
|------|----------|
| TDI | **7** |
| TMS | **13** |
| TCK | **32** |
| TDO | **38** |

---

## Daisy chain topology

**Chain order:** Programmer → **CPLD-CU** → **CPLD-DP** → Programmer

```text
FT232H D1 (TDI) ──────► CU pin 7  (TDI)
CU pin 38 (TDO) ──────► DP pin 7  (TDI)
DP pin 38 (TDO) ──────► FT232H D2 (TDO)

FT232H D0 (TCK) ──┬──► CU pin 32
                  └──► DP pin 32   (parallel)

FT232H D3 (TMS) ──┬──► CU pin 13
                  └──► DP pin 13   (parallel)

Gnd / 5V ───────────── both CPLDs (common)
```

---

## Programming procedure

1. Power both CPLDs **5 V** with **0.1 µF** decoupling each.
2. Connect daisy chain; keep wires **≤ 10 cm**.
3. OpenOCD / WinCUPL: program **CU fuse image first**, then **DP** (CU = larger logic in chain position 0).
4. Verify each device: expect tap ID `0x0150403f` when probed individually.
5. **Run mode:** disconnect programmer; JTAG pins idle — G-IC uses DP pins 12,14,16–20 (not 7/38 if chain wires removed).

---

## Signal integrity

| Concern | Mitigation |
|---------|------------|
| TDO→TDI level | 5 V CMOS both devices; single 74HC04 buffer optional if >15 cm |
| TCK skew | Parallel TCK/TMS to both chips; match wire length |
| Chain break | Can ISP each chip standalone by connecting programmer TDI/TDO to that chip only |
| Run-mode pin conflict | DP pin 7/38 are JTAG — **do not** route G-IC on 7/38; G-IC uses 12,14,16–20 |

---

## BOM add-on

| Item | Qty | Notes |
|------|-----|-------|
| ATF1504AS-10JU44 | +1 vs v1.0 | Second CPLD |
| PLCC-44 adapter | +1 | BOM #15 class |
| JTAG ribbon | 1 | 2×5 1.27 mm optional header |

No extra EEPROM or 74HC logic vs F2-BA.
