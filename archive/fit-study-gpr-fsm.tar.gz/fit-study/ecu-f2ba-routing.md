# F2-BA ECU — 27-wire routing specification

**Scenario:** F2-BA · **CPLD:** [variants/f2_datapath/system_ctrl.pld](variants/f2_datapath/system_ctrl.pld)  
**Hardware:** [ecu-f2ba-hardware.md](ecu-f2ba-hardware.md)

Signal wires **W01–W27** connect ECU glue, shared SoC nets, and CPLD-DP.  
**Separate bundle:** `q_a[7:0]` + `q_b[7:0]` (16 wires) CPLD → ALU operands — not counted in ECU 27.

---

## Bundle diagram

```mermaid
flowchart LR
  subgraph soc [SoC nets]
    IR[IR574]
    FLG[FLG574]
    BUS[Data bus D7_0]
    CLKnet[CLK]
    PC[PC574]
  end
  subgraph ecu [ECU F2-BA]
    SEQ[EEPROM seq]
    TFR[TFR 08/32]
    BR[Branch 153]
  end
  subgraph cpld [CPLD-DP]
    GPR[GPR TFR]
  end
  IR -->|W01-05| SEQ
  IR -->|W01-05| TFR
  FLG -->|W06| BR
  CLKnet -->|W07| SEQ
  SEQ -->|W08-09| SEQ
  SEQ -->|W10| BR
  BUS <-->|W11-18| SEQ
  BUS <-->|W11-18| GPR
  TFR -->|W19-22| GPR
  BR -->|W26| PC
  SEQ -->|W27| SEQ
```

---

## W01–W27 table

| Wire | Signal | Dir | Source IC/net | Dest IC/net | Notes |
|------|--------|-----|---------------|-------------|-------|
| W01 | `opc0` | →ECU | IR574 Q0 | EEPROM A0, 08/32 TFR | IR tap |
| W02 | `opc1` | →ECU | IR574 Q1 | EEPROM A1, TFR decoder | |
| W03 | `opc2` | →ECU | IR574 Q2 | EEPROM A2, idx LUT | |
| W04 | `opc3` | →ECU | IR574 Q3 | EEPROM A3, idx LUT | |
| W05 | `opc4` | →ECU | IR574 Q4 | EEPROM A4, `tfr_valid` tree | |
| W06 | `flg_z` | →ECU | FLG574 Q (Z) | 74HC153 MUX | Not on CPLD |
| W07 | `clk` | →ECU | 2 MHz dist | 161, CW 574, CPLD pin 43 | Common clock |
| W08 | `ph0` | ECU int | 161 Q0 | EEPROM A5 | Phase addr |
| W09 | `ph1` | ECU int | 161 Q1 | EEPROM A6 | Phase addr |
| W10 | `macro_end` | ECU int | 161 glue | 08 AND → branch | One-shot @ macro end |
| W11 | `d_in0` | bidir | Data bus | CPLD pin 1, EEPROM D0 | Shared bus |
| W12 | `d_in1` | bidir | Data bus | CPLD pin 2, EEPROM D1 | |
| W13 | `d_in2` | bidir | Data bus | CPLD pin 4, EEPROM D2 | |
| W14 | `d_in3` | bidir | Data bus | CPLD pin 5, EEPROM D3 | |
| W15 | `d_in4` | bidir | Data bus | CPLD pin 6, EEPROM D4 | |
| W16 | `d_in5` | bidir | Data bus | CPLD pin 8, EEPROM D5 | |
| W17 | `d_in6` | bidir | Data bus | CPLD pin 9, EEPROM D6 | |
| W18 | `d_in7` | bidir | Data bus | CPLD pin 11, EEPROM D7 | |
| W19 | `reg_we` | ECU→CPLD | 08 glue / TFR | CPLD pin 12 | Setup P7a |
| W20 | `w_sel0` | ECU→CPLD | idx→dst decode | CPLD pin 14 | |
| W21 | `w_sel1` | ECU→CPLD | idx→dst decode | CPLD pin 16 | |
| W22 | `tfr_valid` | ECU→CPLD | 74HC32 out | CPLD pin 17 | |
| W23 | `idx0` | ECU→CPLD | idx LUT | CPLD pin 18 | |
| W24 | `idx1` | ECU→CPLD | idx LUT | CPLD pin 19 | |
| W25 | `idx2` | ECU→CPLD | idx LUT (tie 0 if unused) | CPLD pin 20 | |
| W26 | `pc_load_en` | ECU→SoC | 153+08 out | PC 574 load | Branch P7b |
| W27 | `cw_le` | ECU int | sequencer | CW_LO + CW_HI 574 CLK | Rising edge load |

**Count:** 27 signal wires (excl. GND/VCC).

---

## CPLD pin cross-reference

From [variants/f2_datapath/system_ctrl.pld](variants/f2_datapath/system_ctrl.pld):

| CPLD pin | Signal | Wire |
|----------|--------|------|
| 43 | `clk` | W07 |
| 1–11 | `d_in[7:0]` | W11–W18 |
| 12 | `reg_we` | W19 |
| 14 | `w_sel0` | W20 |
| 16 | `w_sel1` | W21 |
| 17 | `tfr_valid` | W22 |
| 18–20 | `idx[2:0]` | W23–W25 |
| (outs) | `q_a[7:0]`, `q_b[7:0]` | separate ALU bundle |

---

## ECU-internal (not in W01–W27)

| Net | Route |
|-----|-------|
| `cw_oe`, `cw_bank` | Sequencer → EEPROM / 574 |
| `mem_rd`, `mem_wr`, `y_oe`, ALU ctrl | CW 574 Q → SoC glue |
| `lat_pc_load`, `lat_pc_flg_z` | CW_LO Q + row meta → 153 |

---

## Wiring rules

1. **Bus sharing:** EEPROM `D[7:0]` tri-states when `cw_oe=0`; CPLD `d_in` samples bus on GPR write phases only.
2. **IR tap:** Route `opc[4:0]` parallel to ECU — do not load IR 574 beyond one 08/32 input fanout.
3. **FLG_Z:** Single wire W06 to ECU; CPLD has no `flg_z` pad (pin 36 → `q` MSB per fitter).
4. **Length class:** Breadboard +10 ns derating per hop — [ecu-f2ba-timing.md](ecu-f2ba-timing.md).
