"""G Plan dual CPLD timing — vs F2-BA discrete ECU (fit-study)."""

from __future__ import annotations

from dataclasses import dataclass

from sim.ecu_f2ba_timing import (
    HALF_CYCLE_NS,
    TIMING_WC,
    PathResult,
    path_branch_beq_ns as f2ba_branch,
    path_p8_operand_ns,
    path_tfr_decode_ns as f2ba_tfr,
)

# Inter-chip derating between CPLD-CU and CPLD-DP
INTER_CHIP_NS = 10


@dataclass(frozen=True)
class CompareRow:
    path_id: str
    f2ba_ns: int
    g_dual_ns: int
    delta_ns: int
    formula_g: str

    @property
    def g_slack_ns(self) -> int:
        return HALF_CYCLE_NS - self.g_dual_ns


def path_g_tfr_latch_ns() -> PathResult:
    """t_PD(CU) + t_wire + t_SETUP(DP)"""
    t = TIMING_WC
    terms = (
        ("cpld_cu_tco", t["cpld_tco"]),
        ("inter_chip", INTER_CHIP_NS),
        ("cpld_dp_setup", t["cpld_setup"]),
    )
    total = sum(v for _, v in terms)
    return PathResult(
        path_id="G_TFR_latch",
        formula="t_PD(CU) + t_wire + t_SETUP(DP)",
        terms_ns=terms,
        total_ns=total,
    )


def path_g_branch_beq_ns() -> PathResult:
    """t_ALU + t_FLG + t_CU_merge + t_PC_setup + wire"""
    t = TIMING_WC
    terms = (
        ("alu_sub_y", t["alu_sub_y"]),
        ("hc574_tco", t["hc574_tco"]),
        ("cpld_cu_tco", t["cpld_tco"]),
        ("hc574_setup", t["hc574_setup"]),
        ("inter_chip", INTER_CHIP_NS),
    )
    total = sum(v for _, v in terms)
    return PathResult(
        path_id="G_Branch_BEQ",
        formula="t_ALU(SUB) + t_FLG + t_CU_merge + t_SETUP(PC) + wire",
        terms_ns=terms,
        total_ns=total,
    )


def compare_chart() -> list[CompareRow]:
    f2_tfr = f2ba_tfr()
    g_tfr = path_g_tfr_latch_ns()
    f2_br = f2ba_branch()
    g_br = path_g_branch_beq_ns()
    p8 = path_p8_operand_ns()
    return [
        CompareRow("TFR_latch", f2_tfr.total_ns, g_tfr.total_ns, g_tfr.total_ns - f2_tfr.total_ns, g_tfr.formula),
        CompareRow("Branch_BEQ", f2_br.total_ns, g_br.total_ns, g_br.total_ns - f2_br.total_ns, g_br.formula),
        CompareRow("P8_operand", p8.total_ns, p8.total_ns, 0, "unchanged DP internal"),
    ]


def branch_slack_improvement_ns() -> int:
    return path_g_branch_beq_ns().slack_ns - f2ba_branch().slack_ns


def assert_g_improves_branch_slack() -> None:
    if branch_slack_improvement_ns() <= 0:
        raise AssertionError("G dual branch slack should exceed F2-BA")


def assert_all_g_paths_within_half_cycle(half_ns: int = HALF_CYCLE_NS) -> None:
    for p in (path_g_tfr_latch_ns(), path_g_branch_beq_ns(), path_p8_operand_ns()):
        if p.total_ns > half_ns:
            raise AssertionError(f"{p.path_id}: {p.total_ns}ns > {half_ns}ns")
