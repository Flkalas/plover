"""F2-BA ECU critical-path timing — worst-case propagation model (fit-study)."""

from __future__ import annotations

from dataclasses import dataclass

# 74HC @ 5V datasheet max (ns) — desk from alu-opcodes-timing.md + Nexperia 74HC family
TIMING_WC: dict[str, int] = {
    "hc08_tpd": 22,
    "hc32_tpd": 22,
    "hc04_tpd": 22,
    "hc153_tpd": 48,
    "hc161_tpd": 35,
    "hc574_tco": 23,
    "hc574_setup": 28,
    "eeprom_tacc": 70,
    "cpld_setup": 15,
    "cpld_tco": 15,
    "alu_sub_y": 136,
    "alu_inc_y": 153,
    "cmp_flags_max": 151,
    "breadboard": 10,
    "margin_setup": 30,
}

HALF_CYCLE_NS = 250  # 2.0 MHz execute half-cycle
NOMINAL_CLK_MHZ = 2.0


@dataclass(frozen=True)
class PathResult:
    path_id: str
    formula: str
    terms_ns: tuple[tuple[str, int], ...]
    total_ns: int
    half_cycle_ns: int = HALF_CYCLE_NS

    @property
    def slack_ns(self) -> int:
        return self.half_cycle_ns - self.total_ns

    @property
    def pass_half_cycle(self) -> bool:
        return self.total_ns <= self.half_cycle_ns


def path_tfr_decode_ns() -> PathResult:
    """t_PD(TFR) = t_08 + t_32 + t_SETUP(CPLD) + t_wire"""
    t = TIMING_WC
    terms = (
        ("hc08_tpd", t["hc08_tpd"]),
        ("hc32_tpd", t["hc32_tpd"]),
        ("cpld_setup", t["cpld_setup"]),
        ("breadboard", t["breadboard"]),
    )
    total = sum(v for _, v in terms)
    return PathResult(
        path_id="TFR_decode",
        formula="t_08 + t_32 + t_SETUP(CPLD) + t_wire",
        terms_ns=terms,
        total_ns=total,
    )


def path_branch_beq_ns() -> PathResult:
    """t_PD(Branch) = t_ALU(SUB) + t_574(FLG) + t_153 + t_SETUP(PC) + t_wire"""
    t = TIMING_WC
    terms = (
        ("alu_sub_y", t["alu_sub_y"]),
        ("hc574_tco", t["hc574_tco"]),
        ("hc153_tpd", t["hc153_tpd"]),
        ("hc574_setup", t["hc574_setup"]),
        ("breadboard", t["breadboard"]),
    )
    total = sum(v for _, v in terms)
    return PathResult(
        path_id="Branch_BEQ",
        formula="t_ALU(SUB) + t_574(FLG) + t_153 + t_SETUP(PC) + t_wire",
        terms_ns=terms,
        total_ns=total,
    )


def path_fsm_strobe_ns() -> PathResult:
    """t_PD(FSM) = t_161 + t_EEPROM + t_574_setup + t_wire (fetch slot)"""
    t = TIMING_WC
    terms = (
        ("hc161_tpd", t["hc161_tpd"]),
        ("eeprom_tacc", t["eeprom_tacc"]),
        ("hc574_setup", t["hc574_setup"]),
        ("breadboard", t["breadboard"]),
    )
    total = sum(v for _, v in terms)
    return PathResult(
        path_id="FSM_strobe",
        formula="t_161 + t_EEPROM + t_574_setup + t_wire",
        terms_ns=terms,
        total_ns=total,
    )


def path_p7a_reg_we_ns() -> PathResult:
    """P7a: ECU reg_we → CPLD GPR setup."""
    t = TIMING_WC
    terms = (
        ("hc574_tco", t["hc574_tco"]),
        ("cpld_setup", t["cpld_setup"]),
        ("breadboard", t["breadboard"]),
    )
    total = sum(v for _, v in terms)
    return PathResult(
        path_id="P7a_reg_we",
        formula="t_574_Q + t_SETUP(CPLD) + t_wire",
        terms_ns=terms,
        total_ns=total,
    )


def path_p8_operand_ns() -> PathResult:
    """P8: CPLD q → ALU INC (system critical)."""
    t = TIMING_WC
    terms = (
        ("cpld_tco", t["cpld_tco"]),
        ("alu_inc_y", t["alu_inc_y"]),
    )
    total = sum(v for _, v in terms)
    return PathResult(
        path_id="P8_operand",
        formula="t_CPLD_q + t_ALU(INC)",
        terms_ns=terms,
        total_ns=total,
    )


def path_p7b_pc_load_ns() -> PathResult:
    """P7b: ECU PC_LOAD → PC 574 latch."""
    t = TIMING_WC
    terms = (
        ("hc153_tpd", t["hc153_tpd"]),
        ("hc574_setup", t["hc574_setup"]),
        ("breadboard", t["breadboard"]),
    )
    total = sum(v for _, v in terms)
    return PathResult(
        path_id="P7b_pc_load",
        formula="t_153 + t_SETUP(PC) + t_wire",
        terms_ns=terms,
        total_ns=total,
    )


def margin_chart() -> list[dict[str, object]]:
    """All F2-BA paths for markdown table generation."""
    paths = [
        path_tfr_decode_ns(),
        path_branch_beq_ns(),
        path_fsm_strobe_ns(),
        path_p7a_reg_we_ns(),
        path_p7b_pc_load_ns(),
        path_p8_operand_ns(),
    ]
    rows: list[dict[str, object]] = []
    for p in paths:
        term_str = " + ".join(f"{k}({v})" for k, v in p.terms_ns)
        rows.append(
            {
                "path_id": p.path_id,
                "formula": p.formula,
                "terms": term_str,
                "total_ns": p.total_ns,
                "slack_ns": p.slack_ns,
                "pass": p.pass_half_cycle,
                "vs_half_cycle": "PASS" if p.pass_half_cycle else "FAIL",
            }
        )
    return rows


def system_fmax_mhz() -> float:
    """Fmax from P8 + margin."""
    t = TIMING_WC
    t_exec_min = t["cpld_tco"] + t["alu_inc_y"] + t["margin_setup"]
    return 1000.0 / (2 * t_exec_min)


def assert_all_within_half_cycle(half_ns: int = HALF_CYCLE_NS) -> None:
    """Raise AssertionError if any in-half-cycle path fails."""
    in_cycle = [
        path_tfr_decode_ns(),
        path_branch_beq_ns(),
        path_p7a_reg_we_ns(),
        path_p7b_pc_load_ns(),
        path_p8_operand_ns(),
    ]
    for p in in_cycle:
        if p.total_ns > half_ns:
            raise AssertionError(f"{p.path_id}: {p.total_ns}ns > {half_ns}ns")


def interference_notes() -> dict[str, str]:
    """P7a vs P8 temporal separation (desk)."""
    return {
        "P7a_vs_P8": (
            "P7a (~48ns) completes at phase start; P8 (~168ns) runs inside "
            "execute body — no serial overlap on same net."
        ),
        "Branch_vs_execute": (
            "Branch (~245ns) fires at macro_end only — orthogonal to P8 operand path."
        ),
        "FSM_fetch_slot": (
            "FSM strobe (~143ns) runs at phase boundary before execute — "
            "does not extend P8."
        ),
    }
