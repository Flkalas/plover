"""F2 integration models — CPLD datapath + external control unit (fit-study)."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Literal

from simulators.cyclesim.data.fsm_table import FSM_ROWS
from simulators.cyclesim.data.isa import TFR_OPS, decode_tfr, is_tfr_valid

from .eeprom_cw import CW_HI_BITS, CW_LO_BITS, EepromCtrlStore
from .gpr_flash_fsm import InternalGpr
from .tfr_isa_models import TFR_3BIT_MAP, decode_tfr_3bit

ScenarioId = Literal["F2-AA", "F2-AB", "F2-BA", "F2-BB"]
BranchBench = Literal["rom_map", "mux", "hybrid"]


class F2Scenario(Enum):
    AA = "F2-AA"
    AB = "F2-AB"
    BA = "F2-BA"
    BB = "F2-BB"


# --- Pin budgets (desk-check constants) ---

PIN_BUDGET: dict[str, dict[str, int | bool]] = {
    "F2-AA": {"in": 16, "out": 16, "total": 32, "pass_32": True, "full_q": True},
    "F2-AB": {"in": 14, "out": 19, "total": 33, "pass_32": False, "full_q": True},
    "F2-BA": {"in": 16, "out": 16, "total": 32, "pass_32": True, "full_q": True},
    "F2-BB": {"in": 14, "out": 17, "total": 31, "pass_32": True, "full_q": False},
}


# --- Timing path constants (ns, desk from timing-clock-table.md) ---

TIMING_NS = {
    "cpld_tco": 15,
    "cpld_setup": 15,
    "hc574_tco": 23,
    "hc574_setup": 28,
    "alu_inc": 153,
    "eeprom_tacc": 70,
    "hc153_tpd": 48,
    "hc08_tpd": 22,
    "breadboard": 10,
    "margin_setup": 30,
}


def idx_to_src_dst(idx: int) -> tuple[int, int]:
    if idx < 0 or idx > 5:
        raise ValueError(f"invalid TFR idx={idx}")
    return TFR_3BIT_MAP[idx]


def v10_opcode_to_idx(opcode: int) -> int | None:
    """Map v1.0 TFR opcode to TFR-3bit idx for external decode model."""
    decoded = decode_tfr(opcode)
    if decoded is None:
        return None
    src, dst = decoded
    for idx, pair in enumerate(TFR_3BIT_MAP):
        if pair == (src, dst):
            return idx
    return None


@dataclass
class TfrExternalDecodeModel:
    """F2-BA: IR opc[4:0] → tfr_valid + idx[2:0] (discrete gate model)."""

    # Gate count desk estimate for BOM
    gate_estimate: dict[str, int] = field(
        default_factory=lambda: {"hc08": 3, "hc32": 2, "hc04": 1}
    )

    def decode(self, opcode: int) -> tuple[bool, int]:
        idx = v10_opcode_to_idx(opcode)
        if idx is None:
            return False, 0
        return True, idx

    def decode_all_v10_opcodes(self) -> dict[int, int]:
        out: dict[int, int] = {}
        for op in TFR_OPS:
            valid, idx = self.decode(op)
            assert valid
            out[op] = idx
        return out


@dataclass
class F2DatapathModel:
    """CPLD-DP: on-chip GPR + TFR mux driven by external strobes."""

    gpr: InternalGpr = field(default_factory=InternalGpr)

    def apply_strobes(
        self,
        *,
        reg_we: bool,
        w_sel: int,
        tfr_valid: bool,
        idx: int,
        d_in: int,
    ) -> None:
        if not reg_we:
            return
        if tfr_valid:
            src, dst = idx_to_src_dst(idx)
            data = self.gpr.read(src)
            self.gpr.write(dst, data, True)
        else:
            self.gpr.write(w_sel, d_in, True)

    def execute_tfr_3bit_opcode(self, opcode: int) -> None:
        decoded = decode_tfr_3bit(opcode)
        if decoded is None:
            return
        src, dst = decoded
        for idx, pair in enumerate(TFR_3BIT_MAP):
            if pair == (src, dst):
                self.apply_strobes(reg_we=True, w_sel=dst, tfr_valid=True, idx=idx, d_in=0)
                return

    def execute_tfr_v10_via_external(self, opcode: int, decoder: TfrExternalDecodeModel) -> None:
        valid, idx = decoder.decode(opcode)
        if not valid:
            return
        _, dst = idx_to_src_dst(idx)
        self.apply_strobes(reg_we=True, w_sel=dst, tfr_valid=True, idx=idx, d_in=0)


@dataclass
class EcuFullModel:
    """FSM-A: phase sequencer + EEPROM CW + strobes to datapath and SoC."""

    eeprom: EepromCtrlStore = field(default_factory=EepromCtrlStore)
    opcode: int = 0
    phase: int = 0
    flg_z: bool = False

    def cw_strobes(self) -> dict[str, bool]:
        lo, hi = self.eeprom.lookup(self.opcode, self.phase)
        out: dict[str, bool] = {}
        for i, name in enumerate(CW_LO_BITS):
            out[name] = bool((lo >> i) & 1)
        for i, name in enumerate(CW_HI_BITS):
            out[name] = bool((hi >> i) & 1)
        return out

    def lut_pc_flags(self) -> tuple[bool, bool]:
        """Static template bits from EEPROM row (before FLG_Z merge)."""
        for row in FSM_ROWS:
            if row.opcode == self.opcode and row.phase == self.phase:
                return bool(row.pc_load_en), bool(row.pc_load_flg_z)
        return False, False

    def pc_load_en(self, macro_end: bool) -> bool:
        lat_load, lat_flg_z = self.lut_pc_flags()
        return bool(macro_end and lat_load and (not lat_flg_z or self.flg_z))

    def reg_we_w_sel(self, tfr_valid: bool, idx: int) -> tuple[bool, int]:
        if tfr_valid:
            _, dst = idx_to_src_dst(idx)
            return True, dst
        # Non-TFR macro writes come from CW / decode — model LDA ph1 → R0
        if (self.opcode & 0x1F) == 0x02 and self.phase == 1:
            return True, 0
        return False, 0


@dataclass
class EcuBranchModel:
    """FSM-B: branch evaluation only — three benchmark implementations."""

    bench: BranchBench = "mux"
    flg_z: bool = False
    lat_pc_load: bool = False
    lat_pc_flg_z: bool = False
    macro_end: bool = False
    opcode: int = 0
    phase: int = 0
    eeprom: EepromCtrlStore = field(default_factory=EepromCtrlStore)

    def _lut_from_eeprom(self) -> tuple[bool, bool]:
        lo, _hi = self.eeprom.lookup(self.opcode, self.phase)
        return bool((lo >> 4) & 1), False  # pc_load_en bit; flg_z gate from row metadata

    def _lut_from_row(self) -> tuple[bool, bool]:
        for row in FSM_ROWS:
            if row.opcode == self.opcode and row.phase == self.phase:
                return bool(row.pc_load_en), bool(row.pc_load_flg_z)
        return False, False

    def load_template(self, opcode: int, phase: int) -> None:
        self.opcode = opcode
        self.phase = phase
        self.lat_pc_load, self.lat_pc_flg_z = self._lut_from_row()

    def pc_load_en(self) -> bool:
        if not self.macro_end:
            return False
        if self.bench == "rom_map":
            # Novasaur: separate ROM rows per flag state — BEQ loads only on Z=1 row
            if not self.lat_pc_load:
                return False
            if self.lat_pc_flg_z:
                return bool(self.macro_end and self.flg_z)
            return bool(self.macro_end)
        if self.bench == "mux":
            # Gigatron: discrete MUX on FLG_Z
            return bool(
                self.macro_end
                and self.lat_pc_load
                and (not self.lat_pc_flg_z or self.flg_z)
            )
        # Isetta hybrid: EEPROM bit selects MUX path, then AND FLG_Z
        mux_sel = self.lat_pc_flg_z  # CW bit drives MUX select
        if mux_sel:
            return bool(self.macro_end and self.lat_pc_load and self.flg_z)
        return bool(self.macro_end and self.lat_pc_load and (not self.flg_z))


def rom_map_address_space() -> dict[str, int]:
    """Novasaur-style flag-expanded address estimate."""
    active_rows = len(FSM_ROWS)
    flag_bits = 1  # FLG_Z primary for BEQ
    return {
        "base_idx5_slots": 128,
        "active_rows": active_rows,
        "flag_expansion": 2**flag_bits,
        "rom_rows_with_flags": active_rows * (2**flag_bits),
        "addr_pins_required": 8,  # AT28C64
    }


def critical_path_ns(scenario: ScenarioId, branch_bench: BranchBench = "mux") -> dict[str, int]:
    """Return path delays (ns) for F2 timing desk-check."""
    t = TIMING_NS
    paths: dict[str, int] = {}

    paths["P8_operand"] = t["cpld_tco"] + t["alu_inc"]

    if scenario in ("F2-AA", "F2-BA"):
        paths["P7a_reg_we"] = t["hc574_tco"] + t["cpld_setup"] + t["breadboard"]
        paths["P7b_pc_load"] = t["hc153_tpd"] + t["hc574_setup"] + t["breadboard"]
    else:
        paths["P9_branch"] = t["hc574_tco"] + t["hc153_tpd"] + t["hc574_setup"] + t["breadboard"]
        paths["P7a_reg_we"] = t["hc574_tco"] + t["cpld_setup"] + t["breadboard"]

    worst = max(paths.values())
    paths["worst"] = worst
    paths["T_exec_min"] = worst + t["margin_setup"]
    paths["f_clk_max_mhz"] = int(1000 / (2 * paths["T_exec_min"]))
    return paths


def tfr_3bit_v10_parity() -> bool:
    """All v1.0 TFR pairs map to unique TFR-3bit idx."""
    decoder = TfrExternalDecodeModel()
    for op in TFR_OPS:
        valid, idx = decoder.decode(op)
        if not valid:
            return False
        src, dst = decode_tfr(op)
        assert src is not None and dst is not None
        assert idx_to_src_dst(idx) == (src, dst)
    return True
