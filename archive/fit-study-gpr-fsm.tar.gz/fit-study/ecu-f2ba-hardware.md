﻿# F2-BA ECU — discrete hardware design

**Scenario:** F2-BA (TFR-v10 external decode + full ECU sequencer)  
**Scope:** Research only — [REPORT-f2-external-control.md](REPORT-f2-external-control.md) deep-dive  
**CPLD:** [variants/f2_datapath/](variants/f2_datapath/) — GPR + TFR MUX only (32/32)

---

## 1. Block overview

```text
                    F2-BA External Control Unit (ECU)
  ┌─────────────────────────────────────────────────────────────────┐
  │  Module A: EEPROM sequencer    Module B: TFR decoder            │
  │  ┌──────────┐  AT28C64         ┌────────┐  ┌────────┐           │
  │  │ 74HC161  │──addr[6:0]──────►│ CW ROM │  │ 74HC08 │◄─opc[4:0]│
  │  │ ph0/ph1  │                  └───┬────┘  └───┬────┘           │
  │  └────┬─────┘                      │      ┌────▼────┐           │
  │       │ macro_end                  │      │ 74HC32  │─tfr_valid │
  │       │                            ▼      └────┬────┘           │
  │       │                     ┌──────────┐  idx[2:0] glue        │
  │       │                     │ CW574×2  │       │                 │
  │       │                     └────┬─────┘       │                 │
  │  Module C: Branch MUX            │ ALU/MEM    │ reg_we/w_sel    │
  │  ┌──────────┐  FLG574.flg_z      │ strobes    │                 │
  │  │ 74HC153  │◄───────────────────┼────────────┼──────► CPLD-DP  │
  │  └────┬─────┘                    │            │                 │
  │       └──► pc_load_en ──────────┼──► PC574    │                 │
  └─────────────────────────────────┴────────────┴─────────────────┘
```

Routing: [ecu-f2ba-routing.md](ecu-f2ba-routing.md) · Timing: [ecu-f2ba-timing.md](ecu-f2ba-timing.md)

---

## 2. BOM (ECU add-on vs v1.0)

| # | MPN | Qty | Module | Role |
|---|-----|-----|--------|------|
| Δ1 | AT28C64B-15PU | 1 | A | idx5 CW microcode (256 B) |
| Δ2 | 74HC08N | 2 | B,C | TFR minterms; branch glue |
| Δ3 | 74HC32N | 1 | B | 6-opcode `tfr_valid` OR tree |
| Δ4 | 74HC04N | 1 | B | idx LUT invert |
| Δ5 | 74HC153N | 1 | C | `FLG_Z` branch MUX |
| — | 74HC161N | 0 Δ | A | Reuse v1.0 phase counter |
| — | 74HC574N | 0 Δ | A | Reuse CW_LO/CW_HI |

**ΔDIP total:** +5 (1 EEPROM + 4 logic)

---

## 3. Module A — EEPROM state sequencer

### Address map

`cw_addr[6:0] = { opc[4:0], ph1, ph0 }` — [sim/eeprom_cw.py](sim/eeprom_cw.py)

### CW load

Phase entry: `cw_oe` → `cw_bank=0` + `cw_le` → `cw_bank=1` + `cw_le` — Tier C archived ([control-word-latch.md](../../archive/tier-c-single-cpld/control-word-latch.md) §5).

### reg_we merge

| Condition | Driver |
|-----------|--------|
| `tfr_valid=1` | Module B → CPLD |
| `tfr_valid=0` | CW row + 08 glue |

---

## 4. Module B — TFR decoder

| Opcode | Transfer | idx |
|--------|----------|-----|
| 0x11 | R0←R1 | 0 |
| 0x12 | R0←R2 | 1 |
| 0x14 | R1←R0 | 2 |
| 0x16 | R1←R2 | 3 |
| 0x18 | R2←R0 | 4 |
| 0x19 | R1←R2 | 5 |

`tfr_valid` = OR of six 5-input minterms (74HC08 + 74HC32).

`idx[2:0]` LUT from `opc[3:0]` when `tfr_valid` — golden: `TfrExternalDecodeModel` in [sim/f2_integration.py](sim/f2_integration.py).

| idx | dst | w_sel |
|-----|-----|-------|
| 0,1 | R0 | 00 |
| 2,3 | R1 | 01 |
| 4,5 | R2 | 10 |

---

## 5. Module C — Branch (74HC153)

`pc_load_en = macro_end & lat_pc_load & (!lat_pc_flg_z | FLG_Z)`

- `lat_pc_load` ← CW_LO[4]
- `FLG_Z` ← FLG 574 (not CPLD)
- 153 MUX + 08 AND `macro_end`
