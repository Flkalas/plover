"""F2-BA ECU timing tests — research only."""

from __future__ import annotations

import sys
from pathlib import Path

FIT_STUDY = Path(__file__).resolve().parents[1]
ROOT = FIT_STUDY.parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(FIT_STUDY))

from sim.ecu_f2ba_timing import (  # noqa: E402
    HALF_CYCLE_NS,
    assert_all_within_half_cycle,
    interference_notes,
    margin_chart,
    path_branch_beq_ns,
    path_fsm_strobe_ns,
    path_p7a_reg_we_ns,
    path_p8_operand_ns,
    path_tfr_decode_ns,
    system_fmax_mhz,
)


def test_tfr_decode_path():
    p = path_tfr_decode_ns()
    assert p.total_ns == 69
    assert p.pass_half_cycle
    assert p.slack_ns == 181


def test_branch_beq_path_tight_pass():
    p = path_branch_beq_ns()
    assert p.total_ns == 245
    assert p.pass_half_cycle
    assert p.slack_ns == 5


def test_fsm_strobe_fetch_slot():
    p = path_fsm_strobe_ns()
    assert p.total_ns == 143


def test_p7a_reg_we_early_phase():
    p = path_p7a_reg_we_ns()
    assert p.total_ns == 48
    assert p.pass_half_cycle


def test_p8_operand_system_critical():
    p = path_p8_operand_ns()
    assert p.total_ns == 168
    assert p.slack_ns == 82


def test_all_paths_within_half_cycle():
    assert_all_within_half_cycle(HALF_CYCLE_NS)


def test_system_fmax_supports_2mhz():
    assert system_fmax_mhz() >= 2.0


def test_margin_chart_six_paths():
    rows = margin_chart()
    assert len(rows) == 6
    ids = {r["path_id"] for r in rows}
    assert "TFR_decode" in ids
    assert "Branch_BEQ" in ids
    assert "P8_operand" in ids


def test_interference_notes_present():
    notes = interference_notes()
    assert "P7a_vs_P8" in notes
    assert "Branch_vs_execute" in notes
