"""G Plan dual CPLD timing tests — research only."""

from __future__ import annotations

import sys
from pathlib import Path

FIT_STUDY = Path(__file__).resolve().parents[1]
ROOT = FIT_STUDY.parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(FIT_STUDY))

from sim.ecu_f2ba_timing import path_branch_beq_ns as f2ba_branch  # noqa: E402
from sim.g_dual_timing import (  # noqa: E402
    HALF_CYCLE_NS,
    assert_all_g_paths_within_half_cycle,
    assert_g_improves_branch_slack,
    branch_slack_improvement_ns,
    compare_chart,
    path_g_branch_beq_ns,
    path_g_tfr_latch_ns,
)


def test_g_tfr_latch_faster_than_f2ba():
    g = path_g_tfr_latch_ns()
    assert g.total_ns == 40
    assert g.total_ns < 69


def test_g_branch_faster_than_f2ba():
    g = path_g_branch_beq_ns()
    f2 = f2ba_branch()
    assert g.total_ns == 212
    assert f2.total_ns == 245
    assert g.slack_ns == 38
    assert f2.slack_ns == 5


def test_branch_slack_improvement():
    assert branch_slack_improvement_ns() == 33


def test_g_improves_branch_slack():
    assert_g_improves_branch_slack()


def test_all_g_within_half_cycle():
    assert_all_g_paths_within_half_cycle(HALF_CYCLE_NS)


def test_compare_chart_three_rows():
    rows = compare_chart()
    assert len(rows) == 3
    tfr = next(r for r in rows if r.path_id == "TFR_latch")
    assert tfr.delta_ns == -29
