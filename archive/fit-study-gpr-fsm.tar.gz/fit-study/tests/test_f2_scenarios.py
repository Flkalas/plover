"""F2 scenario tests — research only."""

from __future__ import annotations

import sys
from pathlib import Path

FIT_STUDY = Path(__file__).resolve().parents[1]
ROOT = FIT_STUDY.parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(FIT_STUDY))

from sim.f2_integration import (  # noqa: E402
    EcuBranchModel,
    EcuFullModel,
    F2DatapathModel,
    PIN_BUDGET,
    TfrExternalDecodeModel,
    critical_path_ns,
    rom_map_address_space,
    tfr_3bit_v10_parity,
)
from sim.tfr_isa_models import TFR_3BIT_MAP, decode_tfr_3bit  # noqa: E402
from simulators.cyclesim.data.isa import TFR_OPS, decode_tfr  # noqa: E402


def test_pin_budget_four_scenarios():
    assert len(PIN_BUDGET) == 4
    for sid, row in PIN_BUDGET.items():
        assert row["in"] + row["out"] == row["total"]
    assert PIN_BUDGET["F2-AA"]["pass_32"] and PIN_BUDGET["F2-AA"]["full_q"]
    assert PIN_BUDGET["F2-BA"]["pass_32"] and PIN_BUDGET["F2-BA"]["full_q"]
    assert not PIN_BUDGET["F2-AB"]["pass_32"]
    assert not PIN_BUDGET["F2-BB"]["full_q"]


def test_tfr_external_decode_all_v10_opcodes():
    dec = TfrExternalDecodeModel()
    mapping = dec.decode_all_v10_opcodes()
    assert len(mapping) == len(TFR_OPS)
    for op, idx in mapping.items():
        src, dst = decode_tfr(op)
        assert TFR_3BIT_MAP[idx] == (src, dst)


def test_tfr_3bit_v10_parity():
    assert tfr_3bit_v10_parity()


def test_f2_datapath_tfr_3bit():
    dp = F2DatapathModel()
    dp.gpr.write(1, 0x42, True)
    dp.execute_tfr_3bit_opcode(0x10)  # idx0 R0<-R1
    assert dp.gpr.q_a == 0x42


def test_f2_datapath_tfr_v10_external():
    dp = F2DatapathModel()
    dec = TfrExternalDecodeModel()
    dp.gpr.write(2, 0xAB, True)
    dp.execute_tfr_v10_via_external(0x12, dec)  # R0<-R2
    assert dp.gpr.q_a == 0xAB


def test_ecu_full_beq_pc_load():
    ecu = EcuFullModel(opcode=0x04, phase=1, flg_z=True)
    assert ecu.pc_load_en(macro_end=True)
    ecu.flg_z = False
    assert not ecu.pc_load_en(macro_end=True)


def test_ecu_full_jmp_pc_load():
    ecu = EcuFullModel(opcode=0x05, phase=0, flg_z=False)
    assert ecu.pc_load_en(macro_end=True)


def test_ecu_branch_mux_beq():
    br = EcuBranchModel(bench="mux")
    br.load_template(0x04, 1)
    br.macro_end = True
    br.flg_z = True
    assert br.pc_load_en()
    br.flg_z = False
    assert not br.pc_load_en()


def test_ecu_branch_benchmarks_agree_beq():
    for bench in ("rom_map", "mux", "hybrid"):
        br = EcuBranchModel(bench=bench)
        br.load_template(0x04, 1)
        br.macro_end = True
        br.flg_z = True
        assert br.pc_load_en(), bench
        br.flg_z = False
        assert not br.pc_load_en(), bench


def test_critical_path_within_2mhz_budget():
    exec_half_ns = 250  # 2 MHz
    for sid in ("F2-AA", "F2-BA", "F2-AB", "F2-BB"):
        paths = critical_path_ns(sid)
        assert paths["worst"] <= exec_half_ns, f"{sid} worst={paths['worst']}"
        assert paths["f_clk_max_mhz"] >= 2


def test_rom_map_address_space():
    space = rom_map_address_space()
    assert space["rom_rows_with_flags"] == space["active_rows"] * 2


def test_tfr_3bit_encodings_cover_six_pairs():
    pairs = {decode_tfr_3bit(0x10 | i) for i in range(6)}
    assert len(pairs) == 6
