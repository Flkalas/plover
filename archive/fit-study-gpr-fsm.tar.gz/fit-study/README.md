# ATF1504 FSM fit study (research sandbox)

**Status:** **G Plan promoted** to v1.0 **rev G** — normative docs in `reference/**`, production HDL in `cpld_fsm/hdl/`. This folder retains historical variants (F2, E1, A1) for comparison.

| Tier | Path | Role |
|------|------|------|
| **Normative** | `reference/**`, `cpld_fsm/hdl/system_ctrl_{cu,dp}.pld` | **rev G dual CPLD** |
| **Research** | `cpld_fsm/fit-study/` | Variant studies, desk reports |

## Purpose

Explore ATF1504 fit options that led to **rev G dual CPLD** (promoted 2026-07-06). Production uses full 8b `q_a`/`q_b` on CPLD-DP and direct strobes on CPLD-CU.

## Index

| Path | Content |
|------|---------|
| [REPORT.md](REPORT.md) | Baseline fit study (A1, D5a) |
| [REPORT-e1-gpr-eeprom.md](REPORT-e1-gpr-eeprom.md) | **E1** GPR-in-CPLD + EEPROM FSM report |
| [REPORT-f2-external-control.md](REPORT-f2-external-control.md) | **F2** CPLD datapath + external ECU (4 scenarios) |
| [REPORT-f2ba-ecu.md](REPORT-f2ba-ecu.md) | **F2-BA** ECU gate-level design + timing |
| [REPORT-g-dual.md](REPORT-g-dual.md) | **G Plan** dual ATF1504 (CPLD-CU replaces F2-BA ECU) |
| [ecu-f2ba-hardware.md](ecu-f2ba-hardware.md) | F2-BA ECU modules + BOM |
| [ecu-f2ba-routing.md](ecu-f2ba-routing.md) | F2-BA 27-wire routing spec |
| [ecu-f2ba-timing.md](ecu-f2ba-timing.md) | F2-BA critical path chart |
| [pin-budget-variants.md](pin-budget-variants.md) | A1–D5 pin math |
| [pin-budget-e1.md](pin-budget-e1.md) | E1 pin subcases |
| [pin-budget-f2.md](pin-budget-f2.md) | F2 four-scenario pin math |
| [pin-budget-g-dual.md](pin-budget-g-dual.md) | G Plan DP/CU pin math + G-IC bundle |
| [g-dual-routing.md](g-dual-routing.md) | G Plan breadboard routing |
| [g-dual-jtag.md](g-dual-jtag.md) | G Plan JTAG daisy chain |
| [g-dual-timing.md](g-dual-timing.md) | G Plan vs F2-BA timing chart |
| [bom-f2-scenarios.md](bom-f2-scenarios.md) | F2 BOM expansion index |
| [tfr-isa-variants.md](tfr-isa-variants.md) | TFR encoding alternatives (fit-study) |
| [timing-clock-table.md](timing-clock-table.md) | P0–P9 paths and `f_clk` derivation |
| [fit-logs/](fit-logs/) | Baseline MC notes, variant synthesis logs |
| [variants/](variants/) | Per-variant PLD forks (not production bitstream) |
| [sim/](sim/) | EEPROM CW, external GPR, F2 integration, F2-BA ECU timing, **G dual timing** |
| [scripts/](scripts/) | `gen_eeprom_cw.py` and variant build helpers |
| [tests/](tests/) | Research-only pytest (v1.0 golden unchanged) |

## Apply

**G Plan — promoted.** Normative: [reference/hardware/cpld-system-controller.md](../../reference/hardware/cpld-system-controller.md). Tier C archived: [archive/tier-c-single-cpld/README.md](../../archive/tier-c-single-cpld/README.md).
