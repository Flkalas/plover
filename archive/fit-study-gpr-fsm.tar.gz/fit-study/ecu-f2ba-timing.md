# F2-BA ECU — critical path timing

**Clock:** 2.0 MHz nominal · **T_exec** = 250 ns half-cycle  
**Source:** [alu-opcodes-timing.md](../../reference/hardware/alu-opcodes-timing.md) max @ 5V · breadboard +10 ns/hop  
**Model:** [sim/ecu_f2ba_timing.py](sim/ecu_f2ba_timing.py) · pytest: [tests/test_ecu_f2ba_timing.py](tests/test_ecu_f2ba_timing.py)

---

## 1. Datasheet worst-case terms

| Symbol | Component | max (ns) | Ref |
|--------|-----------|----------|-----|
| t_08 | 74HC08 prop | 22 | 74HC family @ 5V |
| t_32 | 74HC32 prop | 22 | same |
| t_153 | 74HC153 prop | 48 | timing-clock-table P7b |
| t_161 | 74HC161 prop | 35 | desk |
| t_EEPROM | AT28C64 t_ACC | 70 | P6a |
| t_574_CO | 74HC574 t_CO | 23 | alu-opcodes §3.3 |
| t_574_SU | 74HC574 setup | 28 | alu-opcodes §3.3 |
| t_CPLD | ATF1504 setup/t_CO | 15 | cpld.yaml desk |
| t_ALU_SUB | SUB/CMP Y | 136 | alu-opcodes §3.1 |
| t_ALU_INC | INC Y | 153 | system critical |
| t_wire | breadboard hop | 10 | fit-study derating |

---

## 2. Path accumulation (directive formulas)

| Path ID | Formula | Terms (ns) | **Total** | Slack @ 250 ns | Verdict |
|---------|---------|------------|----------:|---------------:|---------|
| **TFR_decode** | t_08 + t_32 + t_SETUP(CPLD) + t_wire | 22+22+15+10 | **69** | 181 | **PASS** |
| **Branch_BEQ** | t_ALU(SUB) + t_574(FLG) + t_153 + t_SETUP(PC) + t_wire | 136+23+48+28+10 | **245** | 5 | **PASS** (tight) |
| **FSM_strobe** | t_161 + t_EEPROM + t_574_setup + t_wire | 35+70+28+10 | **143** | — | fetch slot |
| **P7a_reg_we** | t_574_Q + t_SETUP(CPLD) + t_wire | 23+15+10 | **48** | — | early phase |
| **P7b_pc_load** | t_153 + t_SETUP(PC) + t_wire | 48+28+10 | **86** | — | macro_end |
| **P8_operand** | t_CPLD_q + t_ALU(INC) | 15+153 | **168** | 82 | **system critical** |

---

## 3. System Fmax

```
T_exec_min = P8 + margin_setup = 168 + 30 = 198 ns
f_clk_max  = 1 / (2 × 198 ns) ≈ 2.53 MHz
```

Nominal **2.0 MHz:** **22% slack** on P8 — unchanged from baseline Tier C.

---

## 4. P7a / P8 interference analysis

| Concern | Assessment |
|---------|------------|
| **P7a (48 ns) vs P8 (168 ns)** | `reg_we`/`w_sel` stable at phase **start**; operand path runs **inside** phase — no net contention |
| **Branch (245 ns) vs execute** | `PC_LOAD` only @ **macro_end** — after BEQ ph1 body; does not steal P8 budget |
| **FSM (143 ns) vs P8** | CW latch at **phase boundary** (fetch slot); latched ALU ctrl stable before execute |
| **TFR decode (69 ns)** | Combinational on IR; settles long before CPLD CLK edge |

**BEQ timeline (worst case):**

```text
ph0: SUB → FLG latch (≤151 ns flags + 28 setup)
ph1: NOP body — P8 may run other ops
macro_end: Branch path 245 ns → PC_LOAD (within ph1 tail / before next fetch)
```

**Risk:** Branch slack **5 ns** — recommend scope check on breadboard; fallback **1.5 MHz** bring-up per [timing-clock-table.md](timing-clock-table.md).

---

## 5. Verification gates

| Gate | Criterion | Result |
|------|-----------|--------|
| TFR @ 2 MHz | t_PD(TFR) ≤ 250 ns | **PASS** (69 ns) |
| Branch @ 2 MHz | t_PD(Branch) ≤ 250 ns | **PASS** (245 ns) |
| CPLD setup | tfr_valid stable before CLK ↑ | **PASS** (181 ns margin) |
| System Fmax | ≥ 2.0 MHz | **PASS** (2.53 MHz desk) |

---

## Related

- [ecu-f2ba-hardware.md](ecu-f2ba-hardware.md) — gate-level design
- [ecu-f2ba-routing.md](ecu-f2ba-routing.md) — W01–W27
- [timing-clock-table.md](timing-clock-table.md) — P0–P9 index
- [REPORT-f2ba-ecu.md](REPORT-f2ba-ecu.md) — summary
