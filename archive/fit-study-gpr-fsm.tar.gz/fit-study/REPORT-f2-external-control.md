# F2 — CPLD datapath + external control (fit-study report)

**Date:** 2026-07-06  
**Scope:** Research only — v1.0 production **unchanged**  
**Sandbox:** `cpld_fsm/fit-study/`  
**Prior reports:** [REPORT.md](REPORT.md) · [REPORT-e1-gpr-eeprom.md](REPORT-e1-gpr-eeprom.md)

---

## 1. Executive summary

**F2** validates splitting the ATF1504 into a **pure GPR/TFR datapath CPLD** plus a **breadboard external control unit (ECU)**. Four scenarios cross **TFR decode** (3bit vs v1.0) with **FSM externalization** (full sequencer vs branch-only).

| Rank | Scenario | 32 pin | 8b q | MC | BOM Δ | ISA | Verdict |
|------|----------|:------:|:----:|---:|------:|-----|---------|
| **1** | **F2-BA** | PASS | PASS | ~18–28 | +EEPROM +2 DIP | v1.0 | **Best SW preservation + full datapath** |
| **2** | **F2-AA** | PASS | PASS | ~18–28 | +EEPROM | TFR remap | **Best BOM if compiler remap OK** |
| **3** | **F2-BB** | PASS | FAIL trim | ~38–43 | +1 MUX | v1.0 | **Min invasive** — branch only |
| **4** | **F2-AB** | FAIL +1 | PASS | ~34–42 | +EEPROM +MUX | TFR remap | Needs JTAG +4 |

**Go/no-go:** No apply to v1.0. Adopt **F2-BA** or **F2-AA** via separate v1.1 plan if breadboard accepts EEPROM burn + ECU wiring.

**Clock:** **2.0 MHz** nominal unchanged — P8 operand 168 ns dominates; P7 strobes have ample margin ([timing-clock-table.md](timing-clock-table.md)).

---

## 2. Four-scenario pin / MC results

Detail: [pin-budget-f2.md](pin-budget-f2.md) · [fit-logs/f2-pin-matrix.md](fit-logs/f2-pin-matrix.md)

| ID | CPLD in | CPLD out | Σ | 32? | 8b q? |
|----|--------:|---------:|--:|:---:|:-----:|
| F2-AA | 16 | 16 | 32 | PASS | PASS |
| F2-AB | 14 | 19 | 33 | FAIL | PASS |
| F2-BA | 16 | 16 | 32 | PASS | PASS |
| F2-BB | 14 | 17 | 31 | PASS | FAIL |

**Key finding:** Removing `opc[4:0]` and `flg_z` from CPLD (**−6 inputs**) and exporting full `q_a`/`q_b` (**+10 outputs** vs Tier C trim) nets **exactly 32/32** for FSM-A — the architectural split E1 could not achieve without +2 pins.

**MC:** F2 datapath fork targets **~18–28 MC** ([fit-logs/f2_datapath-synthesis.md](fit-logs/f2_datapath-synthesis.md)) vs production **43**.

---

## 3. TFR path A vs B

| | **TFR-A (3bit)** | **TFR-B (v1.0)** |
|--|------------------|------------------|
| CPLD pins | Identical 16/16 | Identical 16/16 |
| External | ECU emits `tfr_valid`+`idx` from `0x10\|idx` IR | +74HC08/32 opc decode ([bom-f2-scenarios.md](bom-f2-scenarios.md)) |
| Compiler | Remap to [tfr-isa-variants.md](tfr-isa-variants.md) | **None** |
| Sim parity | [sim/tfr_isa_models.py](sim/tfr_isa_models.py) | `TfrExternalDecodeModel` — 12 pytest |

**Recommendation:** **F2-BA** when v1.0 binary compatibility is mandatory; **F2-AA** when EEPROM path already accepted and toolchain can remap TFR.

---

## 4. FSM path A vs B

| | **FSM-A (full ECU)** | **FSM-B (branch only)** |
|--|----------------------|---------------------------|
| CPLD | GPR + TFR only | E1/Tier C phase + CW |
| ECU | Phase, CW EEPROM, all strobes, `PC_LOAD` | `flg_z` MUX + `PC_LOAD` |
| Wiring | ~27 wires | ~8–12 wires |
| 8b q @ 32 pin | **Yes** (AA/BA) | **No** (BB trim) / AB +1 pin |

**Synchronization:** FSM-A requires ECU `reg_we`/`w_sel` stable before CPLD clock (P7a **48 ns** — well inside 250 ns half-cycle). FSM-B keeps phase edges on CPLD — lower wiring risk, no full-q win.

---

## 5. ECU-Branch benchmarks (FSM-B)

| Benchmark | ΔDIP | Delay | Verdict |
|-----------|-----:|------:|---------|
| **Gigatron MUX** | +1×153 | ~48 ns | **Recommended** — reuses 153 family |
| Novasaur ROM map | +EEPROM 2× rows | ~70 ns | ROM size × flag bits |
| Isetta hybrid | +153 + CW bit | ~70 ns | Highest wiring density |

Sim: [sim/f2_integration.py](sim/f2_integration.py) `EcuBranchModel` — BEQ/JMP agree across benches (pytest).

---

## 6. Position vs prior variants

| Variant | Full q @ 32 | FSM location | Extra ICs |
|---------|:-----------:|--------------|-----------|
| Tier C v1.0 | No | CPLD | 0 |
| A1+A2+A3 | Yes | CPLD | +3×574 |
| E1b-full | No (+2) | CPLD + EEPROM | +EEPROM |
| dual_1504 | Yes | 2nd CPLD | +1 ATF1504 |
| **F2-BA** | **Yes** | **Discrete ECU** | **+EEPROM +2 DIP** |

F2 trades **CPLD complexity** for **discrete glue + wiring** — competitive when team rejects second CPLD or external GPR (A1).

---

## 7. Artifacts

| Path | Role |
|------|------|
| [pin-budget-f2.md](pin-budget-f2.md) | Pin tables |
| [fit-logs/f2-pin-matrix.md](fit-logs/f2-pin-matrix.md) | PASS/FAIL matrix |
| [bom-f2-scenarios.md](bom-f2-scenarios.md) | BOM expansion |
| [timing-clock-table.md](timing-clock-table.md) | P7–P9 paths |
| [sim/f2_integration.py](sim/f2_integration.py) | Integration models |
| [tests/test_f2_scenarios.py](tests/test_f2_scenarios.py) | 12 tests |
| [variants/f2_datapath/](variants/f2_datapath/) | F2-AA/BA PLD |
| [variants/f2_branch_ext/](variants/f2_branch_ext/) | F2-AB/BB PLD |
| [REPORT-f2ba-ecu.md](REPORT-f2ba-ecu.md) | F2-BA ECU hardware + timing |
| [ecu-f2ba-hardware.md](ecu-f2ba-hardware.md) | Gate-level ECU design |
| [ecu-f2ba-routing.md](ecu-f2ba-routing.md) | 27-wire routing |
| [ecu-f2ba-timing.md](ecu-f2ba-timing.md) | Critical path chart |
| [sim/ecu_f2ba_timing.py](sim/ecu_f2ba_timing.py) | Timing model |

---

## 8. Open items

- [ ] WinCUPL F9 on `f2_datapath` / `f2_branch_ext` (local)
- [x] F2-BA ECU gate-level design — [REPORT-f2ba-ecu.md](REPORT-f2ba-ecu.md)
- [ ] Breadboard scope: BEQ branch @ 2 MHz (5 ns desk slack)
- [ ] Compiler backend for TFR-3bit if F2-AA adopted

---

## 9. Recommendations

### Adopt if

- **Full 8b GPR read on strict 32 pins** required without second CPLD or A1 574×3.
- Team accepts **EEPROM CW burn** + moderate breadboard wiring.
- **F2-BA** for zero ISA change; **F2-AA** if TFR remap acceptable.

### Do not adopt if

- **Minimal wiring** priority → stay Tier C or **F2-BB** (accept q trim).
- EEPROM / discrete glue unacceptable → **A1+A2+A3** or **dual_1504**.

**Research conclusion:** F2-BA is the **only single-1504 path** that achieves **32/32 + full 8b q + v1.0 ISA** with desk-check PASS on pins, MC, and timing.
