# BOM expansion — F2 scenarios

**Baseline:** v1.0 [BOM.md](../../reference/project/BOM.md) — ATF1504×1, 574×5, 153×8, 161×3, 08/32×2, no EEPROM.

**v1.0 control-path DIP count (desk):** 574×5 + 161×3 + 138×2 + 08/32×2 + 157×2 (addr) ≈ **16 control ICs** (excludes ALU 12-DIP).

## Metrics

| Metric | Definition |
|--------|------------|
| **ΔDIP** | Added 74HC (or EEPROM) ICs vs v1.0 |
| **Δ574** | Change in octal latch count |
| **ΔEEPROM** | Parallel CW / branch ROM |
| **Wire count** | ECU ↔ SoC signal wires (excl. GND/VCC) |
| **BOM expansion index** | `(ΔDIP + Δadapter) / 16` |

## Scenario summary

| Scenario | ΔDIP | Δ574 | ΔEEPROM | Wires | BOM index | Notes |
|----------|-----:|-----:|--------:|------:|----------:|-------|
| **F2-AA** | +1 | 0 | +1 AT28C64 | ~27 | **0.06** | ECU-Full; TFR-3bit SW remap |
| **F2-BA** | +2 | 0 | +1 AT28C64 | ~27 | **0.13** | +08/32 opc decode for TFR-v10 |
| **F2-AB** | +1 | 0 | +1 (shared) | ~12 | **0.06** | Branch MUX only; **33 I/O** |
| **F2-BB** | +1 | 0 | 0 | ~8 | **0.06** | Min invasive; q trim |

### F2-AA / F2-BA — ECU-Full block BOM

| IC | Qty | Role |
|----|-----:|------|
| AT28C64 (or AT28C256) | 1 | idx5 CW microcode (256 B image exists) |
| 74HC574 | 0 Δ | Reuse CW_LO/CW_HI from v1.0 |
| 74HC161 | 0 Δ | Reuse phase counter |
| 74HC153 | 1 | `PC_LOAD` flag MUX (Gigatron branch bench) |
| 74HC08 | 1 | `macro_end` ∧ strobes glue |

**F2-BA additional TFR-v10 external decode:**

| IC | Qty | Role |
|----|-----:|------|
| 74HC08 | +1 | 6-opc `tfr_valid` comparator |
| 74HC32 | +1 | opcode OR tree |
| 74HC04 | +1 | idx bit invert (desk) |

Desk gate count from [sim/f2_integration.py](sim/f2_integration.py) `TfrExternalDecodeModel.gate_estimate`: 08×3, 32×2, 04×1 — maps to **+2 DIP** (dual gates per package).

### F2-AB / F2-BB — ECU-Branch only

| Benchmark | ΔDIP | EEPROM | Branch delay (desk) |
|-----------|-----:|--------|--------------------:|
| **Gigatron MUX** (recommended) | +1×153, +1×08 | 0 | ~48 ns MUX |
| **Novasaur ROM map** | +1 EEPROM (2× rows) | flag addr ×2 | 70 ns ROM |
| **Isetta hybrid** | +1×153, EEPROM shared | CW bit → MUX sel | ~70 ns |

**F2-BB** reuses Tier C CW bus on CPLD — **no extra EEPROM** if branch MUX taps CW_LO template bits from existing latch.

## Wiring density

| Bundle | F2-AA/BA | F2-AB | F2-BB | dual_1504 ref |
|--------|----------|-------|-------|---------------|
| ECU → CPLD strobes | 12 | 0 | 0 | ~8 |
| ECU → ALU/MEM latch | 14 | 0 | 0 | — |
| ECU branch | 3 | 5 | 5 | — |
| Shared bus tap | 8 | 8 | 8 | 8 |
| **Total est.** | **~27** | **~12** | **~8** | **~20** |

Breadboard congestion: F2-AA/BA **higher** than dual_1504 (more discrete glue); F2-BB **lower**.

## Comparison to prior fit-study variants

| Variant | Full 8b q @ 32 pin | ΔDIP vs v1.0 | SW change |
|---------|---------------------|--------------|-----------|
| Tier C | No | 0 | None |
| A1+A2+A3 | Yes | +3×574 | None |
| E1b-full | No (+2 pin) | +1 EEPROM | Optional TFR |
| **F2-AA** | **Yes** | +1 EEPROM | TFR-3bit |
| **F2-BA** | **Yes** | +1 EEPROM +2 gate | **None** |
| **F2-BB** | No | +1 MUX | **None** |
