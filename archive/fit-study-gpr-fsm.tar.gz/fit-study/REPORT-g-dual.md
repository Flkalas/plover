# G Plan — dual ATF1504 research report

**Date:** 2026-07-06  
**Status:** **Promoted to v1.0 rev G** (2026-07-06)  
**Normative:** [reference/hardware/cpld-system-controller.md](../../reference/hardware/cpld-system-controller.md)

---

## 1. Executive summary

G Plan (G-BA) splits control and datapath into **two ATF1504s**: CPLD-DP holds GPR + full `q`; CPLD-CU holds idx5 FSM + **direct strobes** + **6-wire G-IC** (`src[1:0]` = production TFR mux).

| Gate | Criterion | Result |
|------|-----------|--------|
| DP 32/32 full `q` | pin budget | **PASS** |
| CU 32/32 | 26 used, 6 spare | **PASS** |
| CU MC ≤ 56 | desk estimate | **LIKELY PASS** (~29–35) |
| TFR @ 2 MHz | ≤ 250 ns | **PASS** (40 ns) |
| Branch BEQ @ 2 MHz | ≤ 250 ns | **PASS** (212 ns, **38 ns slack**) |
| vs F2-BA branch | slack improvement | **+33 ns** |
| v1.0 ISA | no remap | **PASS** |
| BOM vs F2-BA | trade | **+1 CPLD**, **−5 DIP**, **−EEPROM** |

**Ranking:** G Plan is the **dual-chip alternative to F2-BA** when discrete ECU wiring or **5 ns branch slack** is unacceptable; pays **+1 ATF1504** for simpler inter-chip routing and internal branch.

---

## 2. Architecture

| Chip | Role | Fork |
|------|------|------|
| **CPLD-DP** | GPR + TFR mux + full `q_a`/`q_b` | [variants/g_dual_dp/](variants/g_dual_dp/) |
| **CPLD-CU** | idx5 FSM + TFR decode + strobes + branch | [variants/g_dual_cu/](variants/g_dual_cu/) |

```mermaid
flowchart LR
  IR[IR opc] --> CU[CPLD-CU]
  FLG[flg_z] --> CU
  CU -->|G-IC 6| DP[CPLD-DP]
  BUS --> DP
  DP -->|q16| ALU
  CU -->|strobes 14| SoC
```

---

## 3. Pin budget

Detail: [pin-budget-g-dual.md](pin-budget-g-dual.md)

| Bundle | Wires |
|--------|------:|
| G-IC CU→DP | **6** |
| F2-BA ECU (baseline) | 27 |
| Reduction | **74%** |

---

## 4. Timing vs F2-BA

| Path | F2-BA | G Plan | Δ |
|------|------:|-------:|--:|
| TFR latch | 69 ns | **40 ns** | −29 |
| Branch BEQ | 245 ns | **212 ns** | −33 |
| P8 operand | 168 ns | 168 ns | 0 |

**Branch compression:** replace 74HC153 (48 ns) with CPLD `t_CO` (15 ns).

Detail: [g-dual-timing.md](g-dual-timing.md) · Model: [sim/g_dual_timing.py](sim/g_dual_timing.py)

---

## 5. Routing and JTAG

| Doc | Content |
|-----|---------|
| [g-dual-routing.md](g-dual-routing.md) | PLCC co-placement, G-IC pin map |
| [g-dual-jtag.md](g-dual-jtag.md) | Daisy chain CU→DP, OpenOCD order |

---

## 6. BOM trade

| Item | F2-BA | G Plan |
|------|-------|--------|
| ATF1504 | 1 | **2** |
| AT28C64 | +1 | **0** |
| 74HC08/32/153/04 | +4 | **0** |
| Inter-chip wires | ~27 | **~7** |

---

## 7. Verification

```
6 passed   tests/test_g_dual_timing.py
41 passed  cpld_fsm/fit-study/tests/  (full fit-study)
```

---

## 8. Open items

- [ ] WinCUPL F9 on `g_dual_cu` and `g_dual_dp` (local)
- [ ] Breadboard dual-CPLD bring-up with JTAG chain
- [ ] Scope BEQ @ 2 MHz on G Plan (expect ≥38 ns slack)

---

## Artifacts

| Path | Role |
|------|------|
| [pin-budget-g-dual.md](pin-budget-g-dual.md) | DP/CU port tables |
| [variants/g_dual_dp/](variants/g_dual_dp/) | Datapath PLD |
| [variants/g_dual_cu/](variants/g_dual_cu/) | Control PLD |
| [fit-logs/g_dual_dp-synthesis.md](fit-logs/g_dual_dp-synthesis.md) | DP desk fit |
| [fit-logs/g_dual_cu-synthesis.md](fit-logs/g_dual_cu-synthesis.md) | CU desk fit |
| [REPORT-f2ba-ecu.md](REPORT-f2ba-ecu.md) | F2-BA baseline |
