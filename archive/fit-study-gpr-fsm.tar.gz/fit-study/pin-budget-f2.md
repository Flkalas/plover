# Pin budget — F2 (CPLD datapath + external control)

**Baseline:** [pin-budget-variants.md](pin-budget-variants.md) · [pin-budget-e1.md](pin-budget-e1.md) · production [../hdl/pin_budget.md](../hdl/pin_budget.md) **unchanged**.

**Device:** ATF1504AS-10JU44 · **32 user I/O** (+ JTAG 7/13/32/38 → **36** run-mode GPIO)

## F2 scenario matrix

| ID | TFR | FSM | CPLD role | External unit (ECU) |
|----|-----|-----|-----------|---------------------|
| **F2-AA** | A: TFR-3bit (`0x10\|idx`) | A: full sequencer | GPR + TFR MUX only | phase, mem/ALU strobes, `reg_we`, `w_sel`, `PC_LOAD` |
| **F2-AB** | A: TFR-3bit | B: branch only | E1 phase FSM + EEPROM CW | `flg_z` eval + `PC_LOAD` |
| **F2-BA** | B: v1.0 6-opc external decode | A: full sequencer | GPR + TFR MUX only | opc decode gates + ECU-Full |
| **F2-BB** | B: v1.0 (`opc` on CPLD) | B: branch only | Tier C/E1 − branch merge | ECU-Branch |

PASS/FAIL desk-check: [fit-logs/f2-pin-matrix.md](fit-logs/f2-pin-matrix.md)

---

## F2 datapath CPLD port (FSM-A: F2-AA / F2-BA)

`flg_z` **removed** from CPLD inputs; freed pad repurposed for full `q_a`/`q_b` export (production pin 36 → `q_a7` or `q_b7` per fitter).

| Direction | Signal | Count | Source / sink |
|-----------|--------|------:|---------------|
| **In** | `d_in[7:0]` | 8 | Data bus |
| | `reg_we` | 1 | ECU phase sequencer |
| | `w_sel[1:0]` | 2 | ECU |
| | `tfr_valid` | 1 | ECU (TFR-B) or derived on ECU from IR (TFR-A: CPLD may also decode idx from bus) |
| | `idx[2:0]` | 3 | ECU TFR index |
| | `CLK` | 1 | System clock |
| **Out** | `q_a[7:0]` | 8 | R0 → ALU A |
| | `q_b[7:0]` | 8 | R1 → ALU B |
| **Σ** | | **32** | **32/32 PASS** · **full 8b q PASS** |

**Not on CPLD:** `OPC[4:0]`, `FLG_Z`, idx5 PLA, phase counter, CW bus, `pc_load_en` merge.

**MC estimate:** GPR 24 FF + TFR comb ≈ **18–28 unique MC** → ≤56 gate **PASS** (desk).

### TFR path pin difference (CPLD side)

| | TFR-A (3bit) | TFR-B (v1.0) |
|--|--------------|--------------|
| CPLD `tfr_valid`/`idx` source | ECU decodes `0x10\|idx` from IR before CPLD | ECU 6-opc comparator → `tfr_valid` + `idx[2:0]` |
| CPLD I/O count | **16 in / 16 out** | **16 in / 16 out** (identical) |
| External BOM delta | EEPROM CW only | +74HC08/32 opc decode glue (see [bom-f2-scenarios.md](bom-f2-scenarios.md)) |

---

## FSM-B CPLD port (F2-AB / F2-BB)

Branch merge and `flg_z` sampling move to **ECU-Branch**; CPLD retains phase FSM + CW fetch.

### F2-AB (E1b − `flg_z`)

| Direction | Signals | Count |
|-----------|---------|------:|
| In | `OPC[4:0]`, `d_in[7:0]`, `CLK` | 14 |
| Out | `q_a[7:0]`, `q_b[7:0]` | 16 |
| Out | `cw_oe`, `cw_le`, `cw_bank` | 3 |
| **Σ** | | **33** |

| Gate | Result |
|------|--------|
| vs 32 cap | **FAIL (+1)** |
| vs 36 JTAG | **PASS** |
| full 8b `q` | **PASS** |
| Mitigation | JTAG +4, or drop `cw_oe` to bus timing strap |

### F2-BB (Tier C − `flg_z`, q trim)

| Direction | Signals | Count |
|-----------|---------|------:|
| In | `OPC[4:0]`, `d_in[7:0]`, `CLK` | 14 |
| Out | `q_a0..2`, `q_b0..2`, `reg_we` | 7 |
| Out | `cw_data[7:0]`, `cw_le`, `cw_bank` | 10 |
| **Σ** | | **31** |

| Gate | Result |
|------|--------|
| vs 32 cap | **PASS (−1 spare)** |
| full 8b `q` | **FAIL** (6-bit export, same as Tier C) |
| Mitigation | q14 fork or JTAG GPIO for MSBs |

### F2-AB q14 / JTAG subcases

| Subcase | In | Out | Σ | 32? | 8b q? |
|---------|---:|----:|--:|:---:|:-----:|
| F2-AB + JTAG | 14 | 19 | 33 | FAIL | PASS @ 36 |
| F2-AB q14 | 14 | 17 | 31 | PASS | 7b/export |
| F2-BB + q14 | 14 | 15 | 29 | PASS | partial |

---

## ECU ↔ SoC routing (FSM-A)

Signals between ECU and rest of SoC (not all are CPLD pads):

| ECU block | Signals | Width | Connects to |
|-----------|---------|------:|-------------|
| Phase 161 | `ph0`, `ph1`, `macro_end` | 3 | idx5 addr, CW sequencer |
| CW EEPROM | `cw_oe`, `cw_le`, `cw_bank`, `D[7:0]` | 11 | Shared data bus, CW 574×2 |
| Strobe latch | `mem_rd`, `mem_wr`, `y_oe`, `flg_we`, `cin`, `bctrl*`, `lgc*`, `s0`, `s1` | 14 | ALU / MEM / FLG |
| GPR drive | `reg_we`, `w_sel[1:0]` | 3 | **CPLD-DP** |
| TFR decode | `tfr_valid`, `idx[2:0]` | 4 | **CPLD-DP** (TFR-B) |
| Branch | `pc_load_en` | 1 | PC 574 load |
| IR tap | `opc[4:0]` | 5 | IR 574 Q (ECU input) |
| Flags tap | `flg_z`, `flg_c` | 2 | FLG 574 Q (ECU input, not CPLD) |

**ECU ↔ CPLD bundle (FSM-A):** `d_in[7:0]` (shared bus), `reg_we`, `w_sel[1:0]`, `tfr_valid`, `idx[2:0]`, `CLK` in; `q_a[7:0]`, `q_b[7:0]` out — **27 wires** + ground (see dual_1504 ~20-wire benchmark).

## ECU-Branch routing (FSM-B)

| ECU block | Signals | Connects to |
|-----------|---------|-------------|
| FLG sampler | `flg_z` (from FLG 574) | Gigatron MUX / ROM addr |
| CW template | `lat_pc_load`, `lat_pc_flg_z` | From CW_LO EEPROM row (static) |
| Branch out | `pc_load_en` | PC 574 `/OE` or load gate |
| CPLD feedback | `macro_end` | Phase FSM on CPLD (wire from 161 or CPLD export if buried) |

**Open resolved in F2:** `pc_load_en = macro_end & lat_pc_load & (!lat_pc_flg_z | FLG_Z)` evaluated **entirely in ECU-Branch** for FSM-B; CPLD does not merge branch.

---

## `flg_z` pin reclaim

Production Tier C: `flg_z` on **pin 36** (input).

| Scenario | Pin 36 role |
|----------|-------------|
| F2-AA / F2-BA | `q_a7` or `q_b7` (fitter assigns) |
| F2-AB / F2-BB | Unused on CPLD; `flg_z` routed to ECU-Branch only |

---

## Variant forks

| Directory | Scenario | Purpose |
|-----------|----------|---------|
| [variants/f2_datapath/](variants/f2_datapath/) | F2-AA, F2-BA | Minimal 16/16 PLD |
| [variants/f2_branch_ext/](variants/f2_branch_ext/) | F2-AB, F2-BB | E1 fork − `flg_z` + external branch stub |
