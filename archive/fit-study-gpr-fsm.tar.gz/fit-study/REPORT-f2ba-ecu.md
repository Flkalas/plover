# F2-BA ECU — research report

**Date:** 2026-07-06  
**Scope:** Research only — v1.0 production **unchanged**  
**Parent:** [REPORT-f2-external-control.md](REPORT-f2-external-control.md) (F2-BA ranked #1)

---

## 1. Executive summary

F2-BA external control unit (ECU) is specified at **gate level** with three modules: **EEPROM sequencer**, **TFR 74HC08/32 decoder**, and **74HC153 branch MUX**. All directive timing paths **PASS** at **2.0 MHz** (250 ns half-cycle) on desk-check; **Branch BEQ** is tight at **5 ns slack**.

| Gate | Criterion | Result |
|------|-----------|--------|
| TFR decode | t_PD ≤ 250 ns | **PASS** (69 ns) |
| Branch BEQ | t_PD ≤ 250 ns | **PASS** (245 ns) |
| CPLD `tfr_valid` setup | stable before CLK ↑ | **PASS** (181 ns margin) |
| System Fmax | ≥ 2.0 MHz | **PASS** (2.53 MHz, P8 limited) |
| Wiring | 27 ECU signal wires | [ecu-f2ba-routing.md](ecu-f2ba-routing.md) |
| v1.0 ISA | 6-opc TFR external | **PASS** (sim parity) |

**Go/no-go:** Research complete — breadboard build not performed. Scope BEQ branch on scope before production adoption.

**Dual-CPLD alternative:** [REPORT-g-dual.md](REPORT-g-dual.md) — replaces this ECU with CPLD-CU (+1 ATF1504, 7-wire G-IC, **+33 ns** branch slack).

---

## 2. Hardware modules

| Module | ICs | Function |
|--------|-----|----------|
| **A — Sequencer** | AT28C64, 74HC161 (reuse), 574×2 (reuse) | idx5 CW fetch, phase, strobes |
| **B — TFR decode** | 74HC08×1, 74HC32×1, 74HC04×1 | v1.0 `opc[4:0]` → `tfr_valid` + `idx[2:0]` |
| **C — Branch** | 74HC153×1, 74HC08 (shared) | `FLG_Z` → `pc_load_en` @ macro_end |

Detail: [ecu-f2ba-hardware.md](ecu-f2ba-hardware.md)

**ΔDIP vs v1.0:** +5 (1 EEPROM + 4 logic DIP)

---

## 3. Critical path timing

| Path | Total (ns) | Slack @ 250 ns |
|------|----------:|---------------:|
| TFR decode | 69 | 181 |
| Branch BEQ | 245 | **5** |
| FSM strobe | 143 | fetch slot |
| P7a reg_we | 48 | early phase |
| P8 operand | **168** | **82** (system) |

**Interference:** P7a and P8 are **time-separated** within the phase; branch fires @ macro_end only — no P8 extension.

Detail: [ecu-f2ba-timing.md](ecu-f2ba-timing.md) · Model: [sim/ecu_f2ba_timing.py](sim/ecu_f2ba_timing.py)

---

## 4. Routing

**W01–W27** numbered spec: [ecu-f2ba-routing.md](ecu-f2ba-routing.md)

CPLD-DP cross-ref: [variants/f2_datapath/system_ctrl.pld](variants/f2_datapath/system_ctrl.pld)

Separate **16-wire** `q_a`/`q_b` bundle: CPLD → ALU (not in ECU 27 count).

---

## 5. Verification

```
9 passed   tests/test_ecu_f2ba_timing.py
35 passed  cpld_fsm/fit-study/tests/  (full fit-study)
```

---

## 6. Open items

- [ ] Breadboard scope: BEQ `pc_load_en` vs FLG_Z @ 2 MHz
- [ ] WinCUPL F9 on `f2_datapath` (local)
- [ ] EEPROM burn on breadboard (M2b slot)

---

## Artifacts

| Path | Role |
|------|------|
| [ecu-f2ba-hardware.md](ecu-f2ba-hardware.md) | Gate-level design + BOM |
| [ecu-f2ba-routing.md](ecu-f2ba-routing.md) | 27-wire routing |
| [ecu-f2ba-timing.md](ecu-f2ba-timing.md) | Worst-case chart |
| [sim/ecu_f2ba_timing.py](sim/ecu_f2ba_timing.py) | Timing calculator |
| [tests/test_ecu_f2ba_timing.py](tests/test_ecu_f2ba_timing.py) | pytest |
| [REPORT-g-dual.md](REPORT-g-dual.md) | G Plan dual CPLD successor |
