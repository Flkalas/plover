# Pin budget — G Plan dual ATF1504

**Scenario:** G-BA — F2-BA datapath + CPLD-CU replaces discrete ECU  
**Parent:** [REPORT-g-dual.md](REPORT-g-dual.md) · [REPORT-f2ba-ecu.md](REPORT-f2ba-ecu.md)

**Device:** 2× ATF1504AS-10JU44 PLCC-44 · **32 user I/O each** (+ JTAG 7/13/32/38 per chip)

---

## Architecture summary

| Chip | Role | Fork |
|------|------|------|
| **CPLD-DP** | GPR 24 FF + TFR idx mux + full `q_a`/`q_b` | [variants/g_dual_dp/](variants/g_dual_dp/) |
| **CPLD-CU** | idx5 FSM + v1.0 TFR decode + branch + direct strobes | [variants/g_dual_cu/](variants/g_dual_cu/) |

**Inter-chip bundle G-IC:** 6 wires (CU → DP) + shared `CLK`

---

## CPLD-DP port map (32/32 PASS)

Inherited from [f2_datapath](variants/f2_datapath/system_ctrl.pld) — unchanged logic.

| Direction | Signals | Count |
|-----------|---------|------:|
| **In** | `d_in[7:0]`, `reg_we`, `w_sel[1:0]`, `tfr_valid`, `src[1:0]`, `CLK` | 15 |
| **Out** | `q_a[7:0]`, `q_b[7:0]` | 16 |
| **Σ** | | **31** (1 spare) |

| Gate | Result |
|------|--------|
| vs 32 cap | **PASS** |
| full 8b `q` | **PASS** |
| `opc` / `flg_z` on DP | **No** — CU only |

**MC estimate:** ~18–28

---

## CPLD-CU port map (27/32 — 5 spare)

| Direction | Signals | Count | Destination |
|-----------|---------|------:|---------------|
| **In** | `opc[4:0]`, `flg_z`, `CLK` | 7 | IR574, FLG574 |
| **Out → SoC** | `mem_rd`, `mem_wr`, `y_oe`, `flg_we`, `pc_load_en`, `cin`, `bctrl0`, `bctrl2`, `lgc0..3`, `s0`, `s1` | 14 | ALU / MEM / PC |
| **Out → DP** | `reg_we`, `w_sel[1:0]`, `tfr_valid`, `src[1:0]` | 6 | G-IC bundle |
| **Σ** | | **26** | **6 spare** |

| Spare pad (desk) | Suggested use |
|------------------|---------------|
| 1 | `macro_end` debug export |
| 4 | strap / future `bctrl1`/`bctrl3` fanout monitor |

**Not on CU:** `d_in[7:0]` — DP receives data bus directly.

**MC estimate:** ~29–35 (idx5 LUT + phase + TFR merge, no GPR)

---

## G-IC inter-chip bundle (CU → DP)

| ID | Signal | CU export | DP pin |
|----|--------|-----------|--------|
| G01 | `reg_we` | merge out | 12 |
| G02 | `w_sel0` | merge out | 14 |
| G03 | `w_sel1` | merge out | 16 |
| G04 | `tfr_valid` | TFR decode | 17 |
| G05 | `src0` | `opc[0]` | 18 |
| G06 | `src1` | `opc[1]` | 19 |

**Shared:** `CLK` → both pin 43 (parallel, not counted in G-IC)

**vs F2-BA ECU:** 27 SoC wires → **6 inter-chip**

Detail: [g-dual-routing.md](g-dual-routing.md)

---

## Comparison

| Metric | F2-BA (1 CPLD + ECU) | G Plan (2 CPLD) |
|--------|----------------------|-----------------|
| Full 8b `q` @ 32 pin/chip | PASS (1 chip) | **PASS** (DP) |
| v1.0 ISA | PASS | **PASS** |
| Extra ICs | +5 DIP + EEPROM | **+1 ATF1504** |
| Inter-chip / ECU wires | ~27 | **~6** |
| Branch BEQ desk | 245 ns (5 slack) | **~212 ns** (38 slack) |

---

## Variant forks

| Directory | Chip |
|-----------|------|
| [variants/g_dual_dp/](variants/g_dual_dp/) | CPLD-DP |
| [variants/g_dual_cu/](variants/g_dual_cu/) | CPLD-CU |
