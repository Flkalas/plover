# G Plan — CPLD-DP (datapath)

**Promoted:** v1.0 rev G — production: `cpld_fsm/hdl/system_ctrl_dp.pld`

## Port

| In | `d_in[7:0]`, G-IC×6, `CLK` |
| Out | `q_a[7:0]`, `q_b[7:0]` |

G-IC: `reg_we`, `w_sel[1:0]`, `tfr_valid`, `src[1:0]`
