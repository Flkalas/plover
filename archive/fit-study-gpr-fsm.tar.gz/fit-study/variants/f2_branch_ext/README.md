# F2 branch external — E1 fork − flg_z (fit-study)

**Scenarios:** F2-AB (TFR-3bit + branch ext), F2-BB (v1.0 + branch ext)

CPLD retains **phase FSM + EEPROM CW fetch**; `flg_z` removed from CPLD; `pc_load_en` merge **stubbed** (ECU-Branch drives PC load).

## Port delta vs E1b-full

| Change | Effect |
|--------|--------|
| Remove `flg_z` input | −1 in; pin 36 free |
| `pc_load_en` buried / stub 0 | Branch in ECU-Branch |
| F2-AB | 14 in / 19 out = **33** (+1 vs 32) |
| F2-BB (Tier C q-trim fork) | 14 in / 17 out = **31** |

## Build

```powershell
.\scripts\build-variant.ps1 -Variant f2_branch_ext
```
