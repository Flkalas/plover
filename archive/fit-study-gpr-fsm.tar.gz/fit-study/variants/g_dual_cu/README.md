# G Plan — CPLD-CU (control)

**Promoted:** v1.0 rev G — production: `cpld_fsm/hdl/system_ctrl_cu.pld`

## Port

| In | `opc[4:0]`, `flg_z`, `CLK` |
| Out SoC | 14 direct strobes |
| Out DP | G-IC 6: `reg_we`, `w_sel`, `tfr_valid`, `src[1:0]` |

Normative: [reference/hardware/cpld-system-controller.md](../../../../reference/hardware/cpld-system-controller.md)
