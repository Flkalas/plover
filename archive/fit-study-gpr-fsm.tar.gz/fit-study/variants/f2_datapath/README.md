# F2 datapath — CPLD GPR + TFR only (fit-study)

**Scenarios:** F2-AA (TFR-3bit), F2-BA (TFR-v10 external decode)

CPLD receives all control strobes from **ECU-Full**; no on-chip FSM, CW bus, or branch merge.

## Port list (32/32)

| In (16) | Out (16) |
|---------|----------|
| `d_in[7:0]`, `reg_we`, `w_sel[1:0]`, `tfr_valid`, `idx[2:0]`, `clk` | `q_a[7:0]`, `q_b[7:0]` |

## Build

```powershell
.\scripts\build-variant.ps1 -Variant f2_datapath
```

WinCUPL F9 locally — target **Design fits**, MC ≤56.

## MC estimate

| Block | MC |
|-------|-----|
| GPR 24 FF | ~24 |
| TFR idx mux + `reg_we`/`w_sel` | ~4–8 |
| **Total** | **~18–28** |
