# G Plan — timing (dual CPLD vs F2-BA)

**Clock:** 2.0 MHz · **T_exec** = 250 ns  
**Model:** [sim/g_dual_timing.py](sim/g_dual_timing.py) · [sim/ecu_f2ba_timing.py](sim/ecu_f2ba_timing.py)

---

## F2-BA vs G Plan comparison

| Path | F2-BA (discrete ECU) | G Plan (dual CPLD) | Δ | G slack @ 250 ns |
|------|---------------------:|-------------------:|--:|-----------------:|
| **TFR latch** | 69 ns | **40 ns** | −29 ns | 210 ns |
| **Branch BEQ** | 245 ns | **212 ns** | −33 ns | **38 ns** |
| **P8 operand** | 168 ns | 168 ns | 0 | 82 ns |

---

## G Plan formulas

### TFR latch window

`t_PD(CU) + t_wire + t_SETUP(DP)` = 15 + 10 + 15 = **40 ns**

CPLD-CU emits `tfr_valid`/`idx` combinationally; CPLD-DP latches on CLK with 210 ns margin before edge (desk).

### Branch BEQ

`t_ALU(SUB) + t_FLG + t_CU_merge + t_SETUP(PC) + wire` = 136 + 23 + **15** + 28 + 10 = **212 ns**

**−33 ns** vs F2-BA by replacing 74HC153 (48 ns) with CPLD internal routing (~15 ns).

### P8 operand

Unchanged — DP internal `q` → ALU INC = **168 ns** (system Fmax **2.53 MHz**).

---

## Interference (P7a / P8 / branch)

| Concern | G Plan assessment |
|---------|-------------------|
| G-IC `reg_we` @ phase start | ~40 ns CU→DP — stable before CLK ↑ |
| P8 operand | DP-only — no CU path extension |
| Branch @ macro_end | 212 ns in ph1 tail — **38 ns slack** (vs F2-BA 5 ns) |
| Inter-chip skew | +10 ns in model; keep G-IC **≤ 8 cm** |

---

## Verification gates

| Gate | G Plan |
|------|--------|
| TFR @ 2 MHz | **PASS** (40 ns) |
| Branch @ 2 MHz | **PASS** (212 ns) |
| Branch slack > F2-BA | **PASS** (+33 ns) |
| System Fmax ≥ 2.0 MHz | **PASS** (P8 limited) |

---

## Related

- [ecu-f2ba-timing.md](ecu-f2ba-timing.md) — discrete ECU baseline
- [timing-clock-table.md](timing-clock-table.md) — P0–P9 index
- [REPORT-g-dual.md](REPORT-g-dual.md) — summary
