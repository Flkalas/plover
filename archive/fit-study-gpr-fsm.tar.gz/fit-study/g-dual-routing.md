# G Plan — breadboard routing

**Scenario:** G-BA dual ATF1504 · **Pins:** [pin-budget-g-dual.md](pin-budget-g-dual.md)

---

## Topology

```mermaid
flowchart LR
  subgraph soc [SoC]
    IR[IR574]
    FLG[FLG574]
    BUS[Data bus]
    ALU[ALU]
  end
  subgraph cu [CPLD-CU socket]
    CU[CPLD-CU]
  end
  subgraph dp [CPLD-DP socket]
    DP[CPLD-DP]
  end
  IR -->|opc5 flg_z| CU
  FLG --> CU
  CU -->|G-IC 6| DP
  BUS --> DP
  DP -->|q16| ALU
  CU -->|strobes14| ALU
```

---

## PLCC co-placement (breadboard)

Place **CPLD-CU** and **CPLD-DP** on **adjacent 830-tie rows** with sockets aligned pin-1 → pin-1.

| Rule | Rationale |
|------|-----------|
| **G-IC on inner tie row** | Shortest CU→DP for `reg_we`, `tfr_valid`, `src` |
| **DP `q_a`/`q_b` to ALU on outer edge** | 16 wires — avoid crossing G-IC bundle |
| **IR/FLG → CU only** | DP has no `opc`/`flg_z` pads |
| **Wire length ≤ 10 cm** | Same as [wiring-flash.md](../../tools/wiring-flash.md) / timing derating |

```text
  [ ALU board ]     [ DP socket ]  [ CU socket ]     [ IR/FLG/PC ]
       ^                 |    G-IC (6)    |                ^
       |                 +----------------+                |
       +-------- q_a/q_b (16) ----------+                 |
                         strobes (14) ---------------------+
```

---

## G-IC bundle (CU → DP)

| ID | Signal | CU pad | DP pad |
|----|--------|--------|--------|
| G01 | `reg_we` | fitter | pin 12 |
| G02 | `w_sel0` | fitter | pin 14 |
| G03 | `w_sel1` | fitter | pin 16 |
| G04 | `tfr_valid` | fitter | pin 17 |
| G05 | `src0` | `opc[0]` | 18 |
| G06 | `src1` | `opc[1]` | 19 |

**CLK:** parallel to both pin 43 (not in G-IC count).

---

## SoC → CU (not inter-chip)

| Signal | Width | Source |
|--------|------:|--------|
| `opc[4:0]` | 5 | IR574 Q |
| `flg_z` | 1 | FLG574 Q |
| `clk` | 1 | 2 MHz dist |

---

## SoC ← CU direct strobes (14)

`mem_rd`, `mem_wr`, `y_oe`, `flg_we`, `pc_load_en`, `cin`, `bctrl0`, `bctrl2`, `lgc0..3`, `s0`, `s1` — same net names as [a1_a2_a3](../variants/a1_a2_a3/).

`bctrl1`/`bctrl3` fanout at 153 per v1.0.

---

## Wire count summary

| Bundle | Wires |
|--------|------:|
| G-IC (CU↔DP) | **6** |
| SoC→CU (opc, flg, clk) | 7 |
| CU→SoC strobes | 14 |
| DP↔bus `d_in` | 8 |
| DP→ALU `q` | 16 |
| **vs F2-BA ECU** | **27 → 7** inter-chip |

JTAG: [g-dual-jtag.md](g-dual-jtag.md)
