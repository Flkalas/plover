# F2 synthesis — desk-check

**Variant:** `f2_datapath`  
**Date:** 2026-07-06  
**WinCUPL:** not run in CI

## Declared I/O

| Direction | Count |
|-----------|------:|
| In | 16 |
| Out | 16 |
| **Total** | **32** |

## MC estimate

| Block | MC |
|-------|-----|
| GPR 24 FF | ~24 |
| TFR idx mux + we decode | ~4–8 |
| **Total** | **~18–28** |

**Gate:** ≤56 unique MC — **LIKELY PASS**

## Notes

- No idx5 PLA, phase FSM, or CW bus on CPLD.
- `flg_z` pad reclaimed for `q_a7` or `q_b7` in production pin lock pass.
- Run locally: `.\scripts\build-variant.ps1 -Variant f2_datapath`
