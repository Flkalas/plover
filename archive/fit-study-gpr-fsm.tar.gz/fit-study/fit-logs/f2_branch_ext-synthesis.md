# F2 branch-ext synthesis — desk-check

**Variant:** `f2_branch_ext`  
**Date:** 2026-07-06  
**WinCUPL:** not run in CI

## Declared I/O (F2-AB baseline)

| Direction | Count |
|-----------|------:|
| In | 14 |
| Out | 19 |
| **Total** | **33** |

**vs 32 cap:** **FAIL (+1)** — JTAG +4 or drop `cw_oe`.

## MC estimate

| Block | MC |
|-------|-----|
| GPR 24 FF | ~24 |
| Phase FSM | ~6 |
| CW fetch sequencer | ~4 |
| TFR comb | ~4–8 |
| Branch merge | **removed** |
| **Total** | **~34–42** |

**Gate:** ≤56 — **LIKELY PASS**

## Notes

- `pc_load_en` stubbed; ECU-Branch (Gigatron MUX recommended) drives PC load.
- `flg_z` not a CPLD input — routed to ECU only.
