# Variant g_dual_cu — synthesis log

| Field | Value |
|-------|-------|
| Variant | G Plan CPLD-CU (idx5 + TFR + direct strobes, no GPR) |
| PLD fork | `variants/g_dual_cu/system_ctrl.pld` |
| Merged | `system_ctrl_gen.pld` (includes production `ctrl_lut.inc`) |
| Device | `f1504ispplcc44` |
| WinCUPL | **Not run** in CI environment (desk check) |

## Pin budget (declared)

| Direction | Count |
|-----------|------:|
| Inputs | 7 (`opc[4:0]`, `flg_z`, `CLK`) |
| Outputs SoC | 14 direct strobes |
| Outputs DP (G-IC) | 6 (`reg_we`, `w_sel×2`, `tfr_valid`, `idx×3`) |
| **Total** | **27 / 32** (5 spare) |

## MC estimate

| Block | MC |
|-------|-----|
| idx5 LUT + phase FSM | ~19 |
| TFR decode + merge | ~6–8 |
| Strobe fanout | ~4 |
| **Total CU** | **~29–35** |

## Structural fit assessment

| Gate | Result |
|------|--------|
| I/O ≤ 32 | **PASS** (27 used) |
| idx5 LUT retained | **PASS** (same `ctrl_lut.inc`) |
| MC ≤ 56 | **LIKELY PASS** (pending local F9) |
| G-IC export | **PASS** (7-wire bundle to DP) |

## Local action

Open `system_ctrl_gen.pld` in WinCUPL → F9 → confirm **Design fits** → update this log.
