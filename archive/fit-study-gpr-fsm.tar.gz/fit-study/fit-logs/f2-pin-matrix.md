# F2 pin matrix — PASS/FAIL

Desk-check from [pin-budget-f2.md](../pin-budget-f2.md). WinCUPL pad lock not run in CI.

## 4-scenario summary

| ID | TFR | FSM | In | Out | Σ I/O | vs 32 | vs 36 JTAG | 32? | 8b q? | MC est. |
|----|-----|-----|---:|----:|------:|------:|-----------:|:---:|:-----:|--------:|
| **F2-AA** | 3bit | Full ext | 16 | 16 | **32** | 0 | −4 | **PASS** | **PASS** | 18–28 |
| **F2-AB** | 3bit | Branch | 14 | 19 | **33** | +1 | 0 | **FAIL** | **PASS** | 25–35 |
| **F2-BA** | v1.0 | Full ext | 16 | 16 | **32** | 0 | −4 | **PASS** | **PASS** | 18–28 |
| **F2-BB** | v1.0 | Branch | 14 | 17 | **31** | −1 | −5 | **PASS** | **FAIL** | 38–43 |

## Subcase mitigations

| ID | Subcase | Σ | 32? | 8b q? | Notes |
|----|---------|--:|:---:|:-----:|-------|
| F2-AB | JTAG +4 | 33 | FAIL@32 | PASS | **PASS @ 36** |
| F2-AB | q14 export | 31 | PASS | 7b | strap MSB |
| F2-BB | q14 + branch ext | 29 | PASS | partial | +2 q bits vs Tier C |
| F2-AA/BA | baseline | 32 | PASS | PASS | **target architecture** |

## Research gate answers

| Question | F2-AA/BA | F2-AB | F2-BB |
|----------|----------|-------|-------|
| Full 8b `q` on strict 32 pins? | **Yes** | Yes (but +1 I/O FAIL) | **No** |
| `flg_z` off CPLD? | Yes | Yes | Yes |
| Phase FSM off CPLD? | Yes | No | No |
| v1.0 binary without remap? | No (AA) / Yes (BA) | No | **Yes** |
| Min external DIP add? | EEPROM path | Branch MUX only | Branch MUX only |

## Fork mapping

| Fork dir | Matrix row |
|----------|------------|
| `f2_datapath` | F2-AA / F2-BA |
| `f2_branch_ext` | F2-AB / F2-BB |
