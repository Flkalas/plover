# G synthesis — desk-check

**Variant:** `g_dual_dp`  
**Date:** 2026-07-06  
**WinCUPL:** not run in CI

## Declared I/O

| Direction | Count |
|-----------|------:|
| In | 16 |
| Out | 16 |
| **Total** | **32** |

## MC estimate

| Block | MC |
|-------|-----|
| GPR 24 FF | ~24 |
| TFR idx mux + we decode | ~4–8 |
| **Total** | **~18–28** |

**Gate:** ≤56 unique MC — **LIKELY PASS**

## Notes

- Logic fork of [f2_datapath](../variants/f2_datapath/system_ctrl.pld) — no `opc`/`flg_z`.
- G-IC inputs: `reg_we`, `w_sel`, `tfr_valid`, `idx` from CPLD-CU.
- Run locally: `.\scripts\build-variant.ps1 -Variant g_dual_dp`
