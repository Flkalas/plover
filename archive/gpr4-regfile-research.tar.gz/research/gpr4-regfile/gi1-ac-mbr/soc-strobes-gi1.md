# Gi1 — CPLD-CU SoC strobes (14 outputs)

**Parent:** [README.md](README.md)  
**Normative:** [cpld-system-controller.md](../../../reference/hardware/cpld-system-controller.md) §2 · [microcode-spec.md](../../../reference/hardware/microcode-spec.md) §4  
**Golden table:** `simulators/cyclesim/data/fsm_table.py` (M3a §2)  
**Gi1 ISA:** [isa-delta.md](isa-delta.md) · [fsm-microcode-delta.md](fsm-microcode-delta.md)

`REG_WE` / `w_sel` are **G-IC → DP**, not part of the 14 SoC outputs.

---

## 1. The 14 outputs — composition

| # | Group | Signal | CPLD pin (desk) | Downstream |
|---|-------|--------|-----------------|------------|
| 1 | **Bus / mem** | `MEM_RD` | 3 | SRAM/ROM `/OE` path via glue |
| 2 | | `MEM_WR` | 10 | SRAM `/WE` path |
| 3 | | `Y_OE` | 15 | ALU `net_y*` → data bus (245 / CPLD `d_in`) |
| 4 | **Seq** | `FLG_WE` | 20 | FLG574 latch clock enable |
| 5 | | `PC_LOAD_EN` | 21 | PC 161 load (branch commit) |
| 6 | **ALU arith** | `cin` | 22 | 283 carry in |
| 7 | | `bctrl0` | 23 | 153 mux2 → **`bctrl1` tied @ 153** |
| 8 | | `bctrl2` | 25 | 153 mux2 → **`bctrl3` tied @ 153** |
| 9–12 | **ALU logic** | `lgc0` … `lgc3` | 26–29 | 153 mux1 (Gigatron 1C0..1C3) |
| 13–14 | **ALU mux** | `s0`, `s1` | 30–31 | → `net_y_mux_sel` (157 sum vs logic) |

**Pin count:** 5 system + 9 ALU = **14**. (`bctrl1`/`bctrl3` are **not** CU pins.)

**Internal CU merge (not exported):** `PC_LOAD_EN` is gated with `FLG_Z` when template = BEQ (`pc_load_flg_z` in sim).

---

## 2. ALU control patterns used by normative ISA

From `fsm_table.py` / [b3-opcode.md](../../../reference/hw-bringup/b3-opcode.md):

| Pattern | `cin` | `bctrl3:0` | `lgc3:0` | `s1:s0` | Used by |
|---------|------:|------------|----------|---------|---------|
| **NOP** | 0 | `0000` | `0000` | `00` | MEM_*, JMP, HALT, BEQ ph1 |
| **ADD** | 0 | `1100` | `0000` | `00` | ADD ph0–2 |
| **SUB/CMP** | 1 | `0011` | `0000` | `00` | CMP ph0–2; BEQ ph0 |

**Not driven by FSM today:** AND, OR, XOR, NOT, INC, DEC, PASS_* — those need **non-zero `lgc` / `s0`/`s1`** ([alu8-phase-b.md](../../../reference/hardware/alu8-phase-b.md)); **M1 bench DIP only**, not M3a opcodes.

---

## 3. Per-opcode strobe matrix (rev G / M3a)

Legend: ● = asserted in frozen LUT row; ○ = deasserted; (G) = via G-IC `reg_we`, not SoC.

| Opcode | Phase | MEM_RD | MEM_WR | Y_OE | FLG_WE | PC_LOAD | ALU |
|--------|-------|:------:|:------:|:----:|:------:|:-------:|-----|
| **ADD** `01` | ph0 | ○ | ○ | ● | ○ | ○ | ADD |
| | ph1 | ○ | ○ | ● | ○ | ○ | ADD; (G) **R1** |
| | ph2 | ○ | ○ | ● | ● | ○ | ADD; (G) **R2** |
| **LDA** `02` | ph0 | ● | ○ | ○ | ○ | ○ | NOP |
| | ph1 | ○ | ○ | ○ | ○ | ○ | NOP; (G) R0 |
| **STA** `03` | ph0 | ○ | ○ | ● | ○ | ○ | NOP |
| | ph1 | ○ | ● | ○ | ○ | ○ | NOP |
| **BEQ** `04` | ph0 | ○ | ○ | ○ | ○ | ○ | SUB |
| | ph1 | ○ | ○ | ○ | ○ | ●≤Z | NOP |
| **JMP** `05` | ph0 | ○ | ○ | ○ | ○ | ● | NOP |
| **LDIO** `08` | ph0/1 | same as LDA | | | | | |
| **STIO** `09` | ph0/1 | same as STA | | | | | |
| **HALT** `0A` | ph0 | all ○ | | | | | |
| **CMP** `0D` | ph0–1 | like ADD | | | | | CMP |
| | ph2 | ○ | ○ | ● | ● | ○ | CMP |
| **STA16** `0F` | ph0/1 | like STA | | | | | |
| **TFR** `11–19` | ph0 | ○ | ○ | ○ | ○ | ○ | (G) xfer only |

**CALL `06` / RET `07`:** encoding exists; **no M3a idx5 rows** — `PC_LOAD_EN` policy TBD.

---

## 4. Gi1 — what changes per strobe

### 4.1 Still required (no Gi1 change)

| Strobe | Why |
|--------|-----|
| **`MEM_RD`** | LDA, LDIO ph0 — load byte into R0 via bus |
| **`MEM_WR`** | STA, STIO, STA16 ph1 |
| **`FLG_WE`** | ADD ph2, CMP ph2 — Z (and carry policy) into FLG574 |
| **`PC_LOAD_EN`** | BEQ, JMP unchanged; abs16 still in MBR |
| **`cin`, `bctrl0`, `bctrl2`** | ADD ph2 (`1100`); CMP ph2 (`0011`+`cin`); BEQ ph0 SUB |

### 4.2 Required, but **LUT rows change**

| Strobe | Gi1 delta |
|--------|-----------|
| **`Y_OE`** | **STA/STIO/STA16 ph0** — unchanged (drive R0 to bus). **ADD ph2** — still **●** (ALU Y → `d_in` → R0 writeback). **ADD/CMP ph0–ph1** — rev G asserts ● for display / R1 latch path; Gi1 **drops ph1 `reg_we`** → **ph0–ph1 `Y_OE` can be ○** (recommended desk). **CMP ph2** — ● in rev G sim; **functionally optional** (flags sample ALU `net_y*`, not bus) — may deassert for cleaner bus |
| **`cin`/`bctrl*`** | Same patterns on **execute phase**; if Gi1 merges to **2-phase ADD**, arithmetic controls only on final phase |

### 4.3 Physically present, **Gi1 ISA never uses non-NOP pattern**

| Strobe | rev G | Gi1 normative ISA |
|--------|-------|-------------------|
| **`lgc0`–`lgc3`** | Routed; FSM always **0000** for M3a opcodes | **Always NOP** — no logic instructions in ISA |
| **`s0`, `s1`** | Routed; FSM always **00** for M3a opcodes | **Always NOP** |

These six nets exist for **ALU hardware completeness** and M1 bring-up parity, not because Gi1 programs AND/OR/etc.

**Optional BOM/routing shave (research):** tie `net_lgc*` / `net_153_s*` to GND at 153 inputs and **stop exporting from CU** → **−6 CU output pins** (see [io-pin-allocation.md](io-pin-allocation.md) monolith note). **Not** proposed for first Gi1 spike on rev G wiring.

### 4.4 Removed with Gi1 (not in the 14)

| Item | Gi1 |
|------|-----|
| TFR comb strobes | **gone** — was G-IC + comb, not SoC |
| ph1 **`reg_we` → R1** | **gone** — G-IC only; frees DP, not CU SoC |

---

## 5. Gi1 strobe matrix (desk proposal)

| Opcode | Phase | MEM_RD | MEM_WR | Y_OE | FLG_WE | PC_LOAD | ALU | G-IC `reg_we` |
|--------|-------|:------:|:------:|:----:|:------:|:-------:|-----|:-------------:|
| **ADD** | ph0 | ○ | ○ | ○* | ○ | ○ | ○* | ○ |
| | ph1 | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| | ph2 | ○ | ○ | **●** | **●** | ○ | ADD | **●** R0 |
| **CMP** | ph0–1 | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| | ph2 | ○ | ○ | ○† | **●** | ○ | CMP | ○ |
| **LDA/LDIO** | — | same as rev G | | | | | | R0 ph1 |
| **STA/STIO/STA16** | — | same as rev G | | | | | | — |
| **BEQ/JMP/HALT** | — | same as rev G | | | | | | — |

\*ph0 optional idle — must **not** pulse MEM_RD or reload MBR operand.  
†CMP ph2 `Y_OE` optional (flags only).

**2-phase ADD option:** collapse ph0+ph1 → fewer cycles; **execute-phase strobes unchanged**.

---

## 6. Summary verdict

| Question | Answer |
|----------|--------|
| Do all **14** SoC outputs stay on CU for Gi1? | **Yes** for first bring-up (rev G pinout / routing) |
| Does Gi1 **need** all 14 **functionally**? | **8 essential** (`MEM_*`, `Y_OE`, `FLG_WE`, `PC_LOAD`, `cin`, `bctrl0`, `bctrl2`); **6 logic mux pins** only as **NOP tie-offs** |
| What **changes** in Gi1? | **LUT timing/content** — fewer `Y_OE`/`reg_we` phases on ALU_REG; **no** strobes deleted from port list |
| Pin savings on CU? | **0** on conservative Gi1; **up to −6** if `lgc`/`s` hardwired (non-normative shave) |
| TFR removal affect SoC 14? | **No** — TFR used G-IC only |

```text
Essential Gi1 SoC bundle (8 dynamic + 6 tied NOP):
  MEM_RD, MEM_WR, Y_OE, FLG_WE, PC_LOAD_EN
  cin, bctrl0, bctrl2
  lgc0..3, s0, s1  →  constant 0 (ISA); pins optional on CPLD
```

---

## Related

- [cpld-dual-delta.md](cpld-dual-delta.md)
- [io-pin-allocation.md](io-pin-allocation.md)
- [fsm-microcode-delta.md](fsm-microcode-delta.md)
- [../variants/gi1_cu/README.md](../variants/gi1_cu/README.md)
