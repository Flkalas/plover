# Gi1 — CPLD-CU / CPLD-DP delta

**Parent:** [README.md](README.md)  
**Normative baseline:** [reference/hardware/cpld-system-controller.md](../../../reference/hardware/cpld-system-controller.md) (rev G)  
**Pins:** [pin-map.md](pin-map.md) · **FSM:** [fsm-microcode-delta.md](fsm-microcode-delta.md)

Gi1 keeps the **2× ATF1504AS-10JU44** split (CU = control, DP = datapath). Only **what each chip does** and **how they handshake** change.

---

## 1. Role split (unchanged topology)

```text
  IR[4:0] ──► CPLD-CU (idx5 FSM, SoC strobes, branch)
                  │
                  └── G-IC ──► CPLD-DP (R0 FF, q_a)
                                    │
  d_bus ◄───────────────────────────┘ (d_in write)

  MBR 574 ──────────────► ALU B     (Gi1: bypasses CPLD-DP)
  q_a ──────────────────► ALU A     (CPLD-DP)
```

| Chip | rev G responsibility | **Gi1** |
|------|---------------------|---------|
| **CPLD-CU** | idx5 FSM; 14 SoC strobes; branch; **G-IC 6**; TFR decode | idx5 FSM; 14 SoC strobes; branch; **G-IC 1**; **no TFR** |
| **CPLD-DP** | R0–R2 FF; `q_a`/`q_b`; TFR xfer mux | **R0 FF**; **`q_a` only**; **no xfer** |

**JTAG:** Unchanged — CU TDI first → DP → TDO; TCK/TMS parallel ([cpld-dual-jtag.md](../../../reference/hardware/cpld-dual-jtag.md)).

---

## 2. CPLD-CU (control unit)

### 2.1 What stays the same

| Function | Detail |
|----------|--------|
| **idx5 FSM** | `(opcode[4:0] << 2) \| phase` — 128 slots |
| **SoC strobes (14)** | `MEM_RD`, `MEM_WR`, `Y_OE`, `FLG_WE`, `PC_LOAD_EN`, ALU `cin`/`bctrl`/`lgc`/`s0`/`s1` — **port list unchanged**; see [soc-strobes-gi1.md](soc-strobes-gi1.md) |
| **Branch** | `PC_LOAD_EN` @ macro_end with `FLG_Z` |
| **Inputs** | `OPC[4:0]` from IR574, `FLG_Z`, `CLK` @ 2 MHz |
| **Fetch** | PC→ROM; operand byte → **MBR** (off-chip 574, not in CPLD) |

CU still **does not** drive `q_a`/`q_b` or touch ALU operand wires directly.

### 2.2 What changes

| Item | rev G | Gi1 |
|------|-------|-----|
| **TFR decode** | 6 opcodes → `tfr_valid`, `src`, `w_sel` on G-IC | **Removed** — `0x10–0x1F` trap/NOP |
| **G-IC to DP** | 6 wires | **1 wire:** `reg_we` only |
| **`reg_we` merge** | `reg_we_lut # tfr_valid` | **`reg_we` = LUT only** (always R0 target in DP) |
| **ADD ph1** | LUT: `REG_WE`, `w_sel=R1` | **No GPR write** on ph1 |
| **ADD ph2** | LUT: `REG_WE`, `w_sel=R2` | LUT: `REG_WE` (implicit R0), `FLG_WE` |
| **CMP ph1** | `REG_WE` → R1 | **No GPR write** |
| **MBR policy** | ph1 may conceptually “use” R1 path | **ALU_REG:** FSM must **not** reload MBR during macro |

### 2.3 CU port budget (desk)

| Direction | rev G | Gi1 |
|-----------|-------|-----|
| In | 7 | **7** (unchanged) |
| Out SoC | 14 | **14** (unchanged) |
| Out G-IC | 6 | **1** |
| **Σ used** | **26** / 32 | **~21** / 32 |
| Spare | 6 | **~11** |

Freed G-IC pins on CU side are **not routed** to DP in Gi1 (DP inputs removed symmetrically).

### 2.4 CU MC (desk)

| Block | rev G | Gi1 Δ |
|-------|-------|-------|
| idx5 LUT | ~20 rows active | **~20** — ph1/ph2 row **content** changes for ADD/CMP |
| TFR comb | ~6 minterms + G-IC drive | **−** |
| Branch merge | unchanged | unchanged |
| **MC estimate** | ~29–35 | **~24–30** |

**Bring-up gate:** WinCUPL **Design fits** (unchanged policy).

### 2.5 CU PLD artifact

No `system_ctrl.pld` fork in repo yet — changes are **idx5 LUT table** + delete TFR equations. Desk memo: [../variants/gi1_cu/README.md](../variants/gi1_cu/README.md).

---

## 3. CPLD-DP (datapath)

### 3.1 What stays the same

| Function | Detail |
|----------|--------|
| **R0 (AC)** | 8 FF @ `CLK`; async read → `q_a` |
| **Bus write** | `d_in[7:0]` → R0 when `reg_we` |
| **Clock** | Pin 43 @ 2 MHz (`net_clk2`) |

DP still **does not** run idx5 FSM or drive `MEM_RD`/`Y_OE`.

### 3.2 What changes

| Item | rev G | Gi1 |
|------|-------|-----|
| **GPR** | R0, R1, R2 (24 FF) | **R0 only (8 FF)** |
| **`q_a`** | `r0*` | `r0*` (unchanged equations) |
| **`q_b`** | `r1*` → ALU B | **not declared / not driven** |
| **`w_sel` decode** | 4-way `we_r0..r3` | **gone** — `reg_we` → R0 CE only |
| **TFR xfer mux** | `tfr_valid` ? mux(src) : `d_in` | **gone** — always `d_in` |
| **ALU B** | from `q_b` | from **`net_mbr`** (off-chip) |

### 3.3 DP port budget (desk)

| Direction | rev G | Gi1 |
|-----------|-------|-----|
| In | 15 (8+6+1) | **9** (8+1) |
| Out | 16 | **8** |
| **Σ** | **31** / 32 | **17** / 32 |
| Spare | 1 | **15** |

Declared pins: [pin-map.md](pin-map.md) §2.

### 3.4 DP MC (desk)

| Block | rev G | Gi1 |
|-------|-------|-----|
| GPR FF | 24 | **8** |
| `w_sel` decode | 4 terms | **0** |
| TFR 4:1 mux × 8 | 8 FF path | **0** |
| `q_a`/`q_b` buffers | 16 out | **8 out** |
| **MC estimate** | ~18–28 | **~10–18** |

### 3.5 DP PLD artifact

[../variants/gi1_dp/system_ctrl.pld](../variants/gi1_dp/system_ctrl.pld) — R0-only skeleton.

---

## 4. G-IC handshake (CU ↔ DP)

### rev G (6 wires)

```text
  CU ── reg_we ──────────────► DP
  CU ── w_sel[1:0] ───────────► DP
  CU ── tfr_valid ───────────► DP
  CU ── src[1:0] ────────────► DP
```

### Gi1 (1 wire)

```text
  CU ── reg_we ──────────────► DP  (write R0 from d_in @ ph1/ph2 when LUT says so)
```

| Strobe timing (ADD) | CU asserts | DP action |
|---------------------|------------|-----------|
| ph1 | `reg_we` **deasserted** | — |
| ph2 | `reg_we` **asserted** @ ↑ | latch `d_in` → **R0** (ALU result via `Y_OE`) |

`w_sel` is **implicit R0** inside DP — CU does not export select bits.

---

## 5. What is *outside* both CPLDs (Gi1)

| Resource | Owner | Gi1 role |
|----------|-------|----------|
| **MBR 574** | Fetch glue + CU `FETCH` timing | **ALU B operand** via `net_mbr→net_b` |
| **PC / IR / FLG** | 574 + CU decode | unchanged |
| **ALU 8** | Breadboard | unchanged |
| **ROM/RAM** | External | unchanged |

Gi1 **does not** move MBR into CPLD-DP — only **wiring + FSM hold** change.

---

## 6. Side-by-side summary

| | **CPLD-CU** | **CPLD-DP** |
|---|-------------|-------------|
| **Gi1 theme** | Simpler G-IC; no TFR; LUT targets R0 | Minimal GPR; single read port |
| **Pins freed** | ~5 G-IC out | ~14 in/out |
| **Critical path** | Branch BEQ (~212 ns) — unchanged | **P8 shorter** (~25 ns start vs ~168 ns) |
| **PLD in repo** | README memo only | `gi1_dp/system_ctrl.pld` |
| **Risk** | idx5 row edits | Breadboard **MBR→B** wire |

---

## Related

- [soc-strobes-gi1.md](soc-strobes-gi1.md)
- [architecture.md](architecture.md)
- [fsm-microcode-delta.md](fsm-microcode-delta.md)
- [../variants/gi1_dp/README.md](../variants/gi1_dp/README.md)
- [../variants/gi1_cu/README.md](../variants/gi1_cu/README.md)
