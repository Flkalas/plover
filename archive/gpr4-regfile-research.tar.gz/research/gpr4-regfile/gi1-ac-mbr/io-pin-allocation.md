# Gi1 I/O pin allocation and single-CPLD feasibility

**Parent:** [README.md](README.md)  
**Baseline:** [pin-map.md](pin-map.md) · [cpld-dual-delta.md](cpld-dual-delta.md)  
**Device:** ATF1504AS-10JU44 PLCC-44

---

## 1. ATF1504 pin pool (counting rules)

| Pool | Pins | Notes |
|------|------|-------|
| **User I/O budget** | **32** | Declared in WinCUPL; bring-up gate |
| **JTAG (ISP)** | 7, 13, 32, 38 | Reserved — not in the 32 |
| **Global clock** | **43** | `CLK` / `net_clk2` — dedicated input; **listed separately** from the 32 in desk tables below |
| **Power / NC** | 44, others | Per datasheet |

**Desk convention (this folder):** Σ in tables = **inputs + outputs** on user I/O pads; **pin 43** shown but not added to the 32 cap (matches [baseline-rev-g.md](../baseline-rev-g.md) DP row: 15 in includes `CLK` in one table, excluded in another — here we **exclude CLK from Σ** for cross-variant compare).

---

## 2. Gi1 dual — signal inventory

### 2.1 World-facing nets (breadboard)

| Direction | Signals | Count |
|-----------|---------|------:|
| **In** | `OPC[4:0]` ← IR574 | 5 |
| **In** | `FLG_Z` ← FLG574 | 1 |
| **In** | `d_in[7:0]` ← data bus | 8 |
| **Out** | SoC strobes (MEM, ALU, branch) | 14 |
| **Out** | `q_a[7:0]` → ALU A | 8 |
| **Inter-chip** | `reg_we` (CU → DP only) | 1 |
| **Clock** | `net_clk2` @ 2 MHz | 1 (pin 43 ×2) |

**Unique functional wires** (if merged): **5+1+8+14+8 = 36** user I/O (+ shared CLK).

### 2.2 Per-chip budget (desk)

| Chip | In | Out | **Σ / 32** | Spare |
|------|---:|----:|-----------:|------:|
| **CPLD-CU** | 6 (`OPC`, `FLG`) | 14 SoC + 1 G-IC | **21** | **11** |
| **CPLD-DP** | 9 (`d_in`, `reg_we`) | 8 (`q_a`) | **17** | **15** |
| **2-chip total** | — | — | **38** pad declarations | **26** free across both |

G-IC `reg_we` consumes **1 CU output + 1 DP input** — not duplicated in the “36 unique world wires” row.

---

## 3. CPLD-DP — PLCC assignment (declared)

From [../variants/gi1_dp/system_ctrl.pld](../variants/gi1_dp/system_ctrl.pld):

| Pin | Dir | Signal | Destination |
|-----|-----|--------|-------------|
| 1 | in | `d_in0` | data bus |
| 2 | in | `d_in1` | |
| 4 | in | `d_in2` | |
| 5 | in | `d_in3` | |
| 6 | in | `d_in4` | |
| 8 | in | `d_in5` | |
| 9 | in | `d_in6` | |
| 11 | in | `d_in7` | |
| 12 | in | `reg_we` | ← CPLD-CU (G-IC) |
| 3 | out | `q_a0` | ALU A0 |
| 10 | out | `q_a1` | ALU A1 |
| 15 | out | `q_a2` | ALU A2 |
| 24 | out | `q_a3` | ALU A3 |
| 25 | out | `q_a4` | ALU A4 |
| 26 | out | `q_a5` | ALU A5 |
| 27 | out | `q_a6` | ALU A6 |
| 28 | out | `q_a7` | ALU A7 |
| 43 | in | `clk` | `net_clk2` |

### DP spare pads (desk)

**15** of 32 user I/O free: 14, 16, 17, 18, 19, 20, 21, 22, 23, 29, 30, 31, 33–37, 39–42 (subset usable per fitter).

**Rev G reuse note:** former `q_b` pins 3,10,15,24–28 are **reassigned to `q_a`** in Gi1 (same pads, half the ALU fanout).

---

## 4. CPLD-CU — PLCC assignment (desk proposal)

Production rev G CU pin list lives in archived `g_dual_cu/system_ctrl.pld` (not in active tree). Below is a **desk allocation** aligned with Gi1 DP pad style and [cpld-dual-routing.md](../../../reference/hardware/cpld-dual-routing.md) signal groups — **reconcile with WinCUPL at spike**.

### Inputs (6 + CLK)

| Pin | Signal | Source |
|-----|--------|--------|
| 4 | `opc0` | IR574 |
| 5 | `opc1` | |
| 6 | `opc2` | |
| 8 | `opc3` | |
| 9 | `opc4` | |
| 24 | `flg_z` | FLG574 |
| 43 | `clk` | `net_clk2` |

### Outputs — SoC (14)

| Pin | Signal | Function |
|-----|--------|----------|
| 3 | `mem_rd` | Memory read |
| 10 | `mem_wr` | Memory write |
| 15 | `y_oe` | Bus drive (STA) |
| 20 | `flg_we` | Flag latch |
| 21 | `pc_load_en` | Branch commit |
| 22 | `cin` | ALU carry in |
| 23 | `bctrl0` | ALU B control (153 fans `bctrl1`) |
| 25 | `bctrl2` | ALU B control (153 fans `bctrl3`) |
| 26 | `lgc0` | ALU logic |
| 27 | `lgc1` | |
| 28 | `lgc2` | |
| 29 | `lgc3` | |
| 30 | `s0` | ALU slice |
| 31 | `s1` | |

### Output — G-IC (1)

| Pin | Signal | To |
|-----|--------|-----|
| 12 | `reg_we` | CPLD-DP pin 12 |

### CU spare pads (desk)

**11** of 32 free: 1, 2, 11, 14, 16, 17, 18, 19, 33–37, 39–42.

---

## 5. Dual-chip wiring map

```text
                    ┌── CPLD-CU ──────────────────────────────┐
  IR574 OPC[4:0] ───┤ in                                     ├── MEM_RD/WR, Y_OE, FLG_WE, PC_LOAD_EN
  FLG574 Z ─────────┤                                        ├── cin, bctrl0/2, lgc0..3, s0/s1
  net_clk2 ─────────┤ pin 43                                 │
                    │ pin 12 reg_we ────────┐                │
                    └───────────────────────┼────────────────┘
                                            │
                    ┌── CPLD-DP ────────────┘                │
  d_bus[7:0] ───────┤ d_in[7:0]                              │
  net_clk2 ─────────┤ pin 43                                 ├── q_a[7:0] ──► ALU A
                    └────────────────────────────────────────┘

  MBR574 Q[7:0] ──────────────────────────────────────────────► ALU B (bypass CPLD)
```

| Bundle | Wires | Length rule |
|--------|------:|-------------|
| G-IC | **1** (`reg_we`) | ≤10 cm ([cpld-dual-routing.md](../../../reference/hardware/cpld-dual-routing.md)) |
| IR/FLG → CU | 6 | Short to CU only |
| `q_a` → ALU | 8 | DP outer edge |
| MBR → ALU B | 8 | **New** Gi1 breadboard wire |

**JTAG:** programmer → **CU (TDI first)** → **DP** → TDO (unchanged).

---

## 6. Comparison — rev G dual vs Gi1 dual

| | rev G CU | Gi1 CU | rev G DP | Gi1 DP |
|---|---------|--------|----------|--------|
| **Σ / 32** | 26 | **21** | 31 | **17** |
| G-IC out | 6 | **1** | — | — |
| G-IC in | — | — | 6 | **1** |
| `q` out | — | — | 16 | **8** |
| GPR FF | — | — | 24 | **8** |

Gi1 frees **5 CU pads** and **14 DP pads** vs rev G — headroom for debug exports or future STR mux **without** changing the 2×1504 BOM.

---

## 7. Single ATF1504 — merge accounting

### 7.1 What merging saves

| Item | Dual Gi1 | Monolithic Gi1 |
|------|----------|----------------|
| G-IC `reg_we` | 2 pads (out+in) | **internal** (−2) |
| Second JTAG device | 2nd chain link | **−1 IC** |
| `OPC`/`FLG` routing | CU only | same |

### 7.2 Required user I/O (direct-strobe rev G style)

| Direction | Signals | Count |
|-----------|---------|------:|
| **In** | `OPC[4:0]`, `FLG_Z`, `d_in[7:0]` | **14** |
| **Out** | SoC strobes | **14** |
| **Out** | `q_a[7:0]` | **8** |
| **Σ** | | **36** |

| vs 32 cap | **FAIL — overrun +4** |

```text
rev G monolithic (3-GPR, full q_a+q_b, direct strobes):
  14 in + 14 strobes + 16 q = 44  →  FAIL +12

Gi1 monolithic (R0 only, no q_b, no TFR):
  14 in + 14 strobes +  8 q = 36  →  FAIL +4

Δ vs rev G monolith: −8 pins (drop q_b) — not enough to close 32
```

### 7.3 MC (desk) — monolithic Gi1

| Block | MC (desk) |
|-------|----------:|
| idx5 FSM + branch (ex-CU) | ~24–30 |
| R0 FF + `q_a` (ex-DP) | ~10–18 |
| **Combined (overlap)** | **~34–48** / 64 |

Archived Tier C monolithic (CW bus + trimmed `q`): **43 MC** — Gi1 direct-strobe is in the same ballpark.

**Binding resource:** **pins**, not MC.

### 7.4 Why dual was chosen for v1.0 rev G

| Architecture | World I/O signals | ATF1504 fit |
|--------------|------------------:|-------------|
| Tier C monolithic (archived) | CW bus + partial `q` | Trimmed to fit **32** |
| **rev G dual** | Split CU/DP | **31 + 26 PASS** |
| **Gi1 dual** | Split CU/DP | **17 + 21 PASS** |
| **Gi1 monolithic** | Merged direct strobes | **36 FAIL +4** |

Dual split exists because **one 1504 cannot hold idx5 + full GPR read ports + 14 direct strobes + 8b bus** without pin tricks (CW latch, bus TDM, or trimmed `q`).

---

## 8. Paths to single chip (if desired)

| ID | Tactic | Pins saved | Gi1 impact |
|----|--------|-------------|------------|
| **M1** | Stay **2×1504** (status quo) | — | **PASS**; simplest vs breadboard BOM |
| **M2** | **ATF1508** (research P4) | >>32 | **PASS** pins+MC; **BOM change** |
| **M3** | Export **`q_a[3:0]`** only; upper nibble internal | **4** | **32 exact** — **breaks 8b ALU A** — **reject** |
| **M4** | Return to **CW bus** + external 574 latch (Tier C) | **~10+** | Fits 32; **adds 574**, timing unlike rev G |
| **M5** | **Bus-TDM** on `q_a` + external 574 (P1-style) | **~4–8** | Overkill for 1 GPR; timing risk |
| **M6** | Time-mux **`d_in`** with `OPC` | **≤4** | **LDA ph1 conflict** — needs per-phase proof |

**Desk recommendation:** Gi1 on **2×1504 PASS** with large spare. Single-chip merge is **not justified** on existing breadboard BOM unless BOM is explicitly revised (M2) or architecture regresses to CW/TDM (M4/M5).

---

## 9. Verdict

| Question | Answer |
|----------|--------|
| Gi1 dual I/O documented? | **Yes** — DP declared; CU desk proposal §4 |
| Gi1 dual fits ATF1504? | **PASS** — CU **21/32**, DP **17/32** |
| Gi1 single ATF1504? | **FAIL pins +4** (36/32); **MC likely PASS** |
| vs rev G single (hypothetical)? | Gi1 **8 pins better** than full 3-GPR monolith, still **4 short** |
| Practical path | **Keep dual**; or **ATF1508** if monolith is a hard requirement |

---

## Related

- [pin-map.md](pin-map.md)
- [cpld-dual-delta.md](cpld-dual-delta.md)
- [bom-delta.md](bom-delta.md)
- [../feasibility-matrix.md](../feasibility-matrix.md) (P4 ATF1508)
- [reference/hardware/cpld-system-controller.md](../../../reference/hardware/cpld-system-controller.md)
