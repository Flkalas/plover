# Gi1 pin map — CPLD-DP / CU

**Device:** ATF1504AS-10JU44 PLCC-44  
**Parent:** [README.md](README.md)  
**Baseline:** [../baseline-rev-g.md](../baseline-rev-g.md) · [../pin-budget.md](../pin-budget.md)

---

## 1. Delta vs rev G

| Item | rev G | Gi1 |
|------|-------|-----|
| GPR in DP | R0–R2 | **R0 only** |
| ALU A | `q_a[8]` | `q_a[8]` ← R0 |
| ALU B | `q_b[8]` ← R1 | **`net_mbr` → ALU** (no CPLD `q_b`) |
| G-IC | 6 wires | **1** (`reg_we`) |
| DP I/O | 31/32 | **~18/32** |

---

## 2. CPLD-DP — declared pins (desk)

### Inputs (9)

| Pin | Signal | Notes |
|-----|--------|-------|
| 1,2,4,5,6,8,9,11 | `d_in[7:0]` | bus write → R0 |
| 12 | `reg_we` | only G-IC strobe |
| 43 | `clk` | 2 MHz |

**Removed inputs:** `w_sel[1:0]`, `tfr_valid`, `src[1:0]` (pins 14,16,17,18,19 free).

### Outputs (8)

| Pin | Signal | Destination |
|-----|--------|-------------|
| 3 | `q_a0` | ALU A0 |
| 10 | `q_a1` | ALU A1 |
| 15 | `q_a2` | ALU A2 |
| 24 | `q_a3` | ALU A3 |
| 25 | `q_a4` | ALU A4 |
| 26 | `q_a5` | ALU A5 |
| 27 | `q_a6` | ALU A6 |
| 28 | `q_a7` | ALU A7 |

**Removed outputs:** `q_b0..7` (former pins — spare).

### Budget

| | Count |
|---|------:|
| In | **9** |
| Out | **8** |
| **Σ** | **17** / 32 |
| Spare | **15** |

---

## 3. CPLD-CU — full port picture (desk)

### Inputs (7) — unchanged

| Signal | Source | Role |
|--------|--------|------|
| `OPC[4:0]` | IR574 | idx5 FSM |
| `FLG_Z` | FLG574 | BEQ @ macro_end |
| `CLK` | pin 43 | 2 MHz phase FSM |

### Outputs — SoC (14) — unchanged

`MEM_RD`, `MEM_WR`, `Y_OE`, `FLG_WE`, `PC_LOAD_EN`, `cin`, `bctrl0`, `bctrl2`, `lgc0..3`, `s0`, `s1` — same as [cpld-system-controller.md](../../../reference/hardware/cpld-system-controller.md) §2.

### Outputs — G-IC to CPLD-DP

| Signal | rev G | Gi1 |
|--------|-------|-----|
| `reg_we` | pin 12 → DP | **yes** |
| `w_sel0` | pin 14 → DP | **removed** |
| `w_sel1` | pin 16 → DP | **removed** |
| `tfr_valid` | pin 17 → DP | **removed** |
| `src0`, `src1` | pins 18–19 → DP | **removed** |

### CU budget

| | rev G | Gi1 |
|---|-------|-----|
| **Σ I/O** | 26/32 | **~21/32** |
| Spare | 6 | **~11** |

**Internal:** delete TFR combinatorial block; ADD/CMP ph1 rows drop `REG_WE`; ph2 ADD targets R0 in LUT narrative (DP hardwires destination).

Detail: [cpld-dual-delta.md](cpld-dual-delta.md) §2.

**Desk PLCC table:** [io-pin-allocation.md](io-pin-allocation.md) §4.

---

## 4. CPLD-DP — G-IC delta (summary)

| Signal | rev G | Gi1 |
|--------|-------|-----|
| `reg_we` | yes | yes |
| `w_sel[1:0]` | yes | **no** |
| `tfr_valid` | yes | **no** |
| `src[1:0]` | yes | **no** |

CU **exports 1** G-IC wire to DP (vs 6). See [cpld-dual-delta.md](cpld-dual-delta.md) §3–4.

---

## 5. Off-chip wiring (breadboard)

| Net | Connection |
|-----|------------|
| `net_mbr0..7` | MBR 574 Q → `net_b0..7` → ALU B |
| `q_a0..7` | CPLD-DP → ALU A (unchanged) |
| `q_b0..7` | **not from CPLD** |

Optional **74HC244** on `net_mbr` → `net_b` if fanout heavy (desk: direct wire OK).

---

## 6. Pin reuse map (rev G → Gi1 spare)

Former `q_b` pins 3,10,15,24–28 may be **unused** or reassigned in future variants (STR mux, debug).

---

## Related

- [cpld-dual-delta.md](cpld-dual-delta.md)
- [../variants/gi1_dp/system_ctrl.pld](../variants/gi1_dp/system_ctrl.pld)
- [../variants/gi1_cu/README.md](../variants/gi1_cu/README.md)
- [bom-delta.md](bom-delta.md)
