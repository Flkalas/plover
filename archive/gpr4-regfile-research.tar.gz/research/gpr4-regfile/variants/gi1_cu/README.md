# gi1_cu — CPLD-CU Gi1 change memo

**Parent:** [../../gi1-ac-mbr/README.md](../../gi1-ac-mbr/README.md)  
**Detail:** [../../gi1-ac-mbr/cpld-dual-delta.md](../../gi1-ac-mbr/cpld-dual-delta.md)

Gi1 **CPLD-CU** changes are **idx5 LUT content** and **G-IC export reduction** — no separate `.pld` fork committed until WinCUPL spike.

---

## Remove

| Block | rev G |
|-------|-------|
| TFR opcode detect (`0x11`…`0x19`) | `tfr_valid` comb |
| G-IC drive | `w_sel[1:0]`, `tfr_valid`, `src[1:0]` |
| `reg_we` merge | `reg_we_lut # tfr_valid` → **`reg_we_lut` only** |

---

## idx5 row edits (desk)

### ADD (`0x01`, base idx 4)

| phase | idx5 | Gi1 strobes |
|-------|------|-------------|
| ph0 | 4 | optional idle / `Y_OE` — **no MBR LE** |
| ph1 | 5 | **no `REG_WE`** |
| ph2 | 6 | `REG_WE` (→ R0 in DP), `FLG_WE`, ALU ADD |

### CMP (`0x0D`, base 52)

| phase | Gi1 |
|-------|-----|
| ph0–1 | no `REG_WE` |
| ph2 | `FLG_WE` only |

### TFR opcodes `0x10–0x1F`

Trap, NOP, or alias to `HALT` — **no** `tfr_valid`.

---

## Unchanged on CU

- 14 direct SoC strobes
- `PC_LOAD_EN` / `FLG_Z` branch
- `OPC[4:0]` from IR574
- `CLK` pin 43 @ 2 MHz

---

## Fit expectation

Desk MC **~24–30** / 64 (down ~5–8 from TFR removal). Pins **~21/32**.

Fork from production `system_ctrl_cu.pld` when bring-up starts (archive / fit-study tarball).
