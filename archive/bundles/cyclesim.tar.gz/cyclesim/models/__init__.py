"""Chip models for cyclesim."""
